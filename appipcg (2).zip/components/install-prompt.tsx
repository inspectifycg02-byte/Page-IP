"use client"

import { useEffect, useState } from "react"
import { Download, X, Smartphone } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

interface BeforeInstallPromptEvent extends Event {
  prompt: () => Promise<void>
  userChoice: Promise<{ outcome: "accepted" | "dismissed" }>
}

export function InstallPrompt() {
  const [deferredPrompt, setDeferredPrompt] = useState<BeforeInstallPromptEvent | null>(null)
  const [showPrompt, setShowPrompt] = useState(false)

  useEffect(() => {
    const handler = (e: Event) => {
      console.log("[PWA] beforeinstallprompt capturado en prompt")
      e.preventDefault()
      setDeferredPrompt(e as BeforeInstallPromptEvent)
    }

    window.addEventListener("beforeinstallprompt", handler)

    const hasDeclined = localStorage.getItem("install-prompt-declined")
    const declinedDate = localStorage.getItem("install-prompt-declined-date")

    if (hasDeclined && declinedDate) {
      const daysSinceDeclined = (Date.now() - Number.parseInt(declinedDate)) / (1000 * 60 * 60 * 24)
      if (daysSinceDeclined > 7) {
        localStorage.removeItem("install-prompt-declined")
        localStorage.removeItem("install-prompt-declined-date")
        setTimeout(() => setShowPrompt(true), 3000)
      }
    } else if (!hasDeclined) {
      setTimeout(() => setShowPrompt(true), 3000)
    }

    return () => {
      window.removeEventListener("beforeinstallprompt", handler)
    }
  }, [])

  const handleInstall = async () => {
    if (deferredPrompt) {
      console.log("[PWA] Mostrando prompt nativo de instalación")
      deferredPrompt.prompt()
      const { outcome } = await deferredPrompt.userChoice
      console.log(`[PWA] Usuario ${outcome === "accepted" ? "aceptó" : "rechazó"} la instalación`)
      setDeferredPrompt(null)
      setShowPrompt(false)
    }
  }

  const handleDismiss = () => {
    localStorage.setItem("install-prompt-declined", "true")
    localStorage.setItem("install-prompt-declined-date", Date.now().toString())
    window.dispatchEvent(new CustomEvent("install-prompt-dismissed"))
    setShowPrompt(false)
  }

  if (!showPrompt) {
    return null
  }

  const isIOS = /iPad|iPhone|iPod/.test(navigator.userAgent)
  const isAndroid = /Android/.test(navigator.userAgent)

  return (
    <div className="fixed bottom-4 left-4 right-4 z-50 mx-auto max-w-sm animate-in slide-in-from-bottom-5">
      <Card className="border-accent shadow-lg">
        <CardHeader className="pb-3">
          <div className="flex items-start justify-between">
            <div className="flex items-center gap-2">
              <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-accent/10">
                <Smartphone className="h-5 w-5 text-accent" />
              </div>
              <CardTitle className="text-lg">Instalar Inspectify CG</CardTitle>
            </div>
            <Button variant="ghost" size="sm" onClick={handleDismiss} className="h-6 w-6 p-0 -mt-1">
              <X className="h-4 w-4" />
            </Button>
          </div>
          <CardDescription className="mt-2">
            Instala la aplicación para acceso rápido y mejor experiencia de usuario
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-2">
          {deferredPrompt ? (
            <>
              <Button onClick={handleInstall} className="w-full bg-accent text-accent-foreground hover:bg-accent/90">
                <Download className="mr-2 h-4 w-4" />
                Instalar Aplicación
              </Button>
              <p className="text-xs text-muted-foreground text-center">Acceso rápido desde tu pantalla de inicio</p>
            </>
          ) : (
            <div className="space-y-3">
              <p className="text-sm font-medium">Para instalar la aplicación:</p>
              {isIOS ? (
                <ol className="text-sm space-y-1 list-decimal list-inside">
                  <li>Toca el botón compartir (□↑)</li>
                  <li>Selecciona &apos;Agregar a pantalla de inicio&apos;</li>
                </ol>
              ) : isAndroid ? (
                <ol className="text-sm space-y-1 list-decimal list-inside">
                  <li>Toca el menú (⋮)</li>
                  <li>Selecciona &apos;Agregar a pantalla de inicio&apos;</li>
                </ol>
              ) : (
                <ol className="text-sm space-y-1 list-decimal list-inside">
                  <li>Busca la opción de menú en tu navegador</li>
                  <li>Selecciona &apos;Instalar aplicación&apos; o &apos;Agregar a pantalla de inicio&apos;</li>
                </ol>
              )}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}
