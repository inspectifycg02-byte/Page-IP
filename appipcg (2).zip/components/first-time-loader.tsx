"use client"

import type React from "react"

import { useEffect, useState } from "react"
import { LoadingScreen } from "./loading-screen"

export function FirstTimeLoader({ children }: { children: React.ReactNode }) {
  const [isFirstTime, setIsFirstTime] = useState(true)
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    const hasVisited = sessionStorage.getItem("hasVisitedApp")

    if (hasVisited) {
      // If already visited in this session, don't show loading screen
      setIsLoading(false)
      setIsFirstTime(false)
    } else {
      // First time visit - show loading screen for 3 seconds
      const timer = setTimeout(() => {
        setIsLoading(false)
        sessionStorage.setItem("hasVisitedApp", "true")
      }, 3000)

      return () => clearTimeout(timer)
    }
  }, [])

  if (isLoading && isFirstTime) {
    return <LoadingScreen message="Bienvenido a Inspectify CG" />
  }

  return <>{children}</>
}
