"use client"

import { useEffect, useState } from "react"
import { Download, X } from "lucide-react"
import { Button } from "@/components/ui/button"

interface BeforeInstallPromptEvent extends Event {
  prompt: () => Promise<void>
  userChoice: Promise<{ outcome: "accepted" | "dismissed" }>
}

export function InstallNotification() {
  const [showNotification, setShowNotification] = useState(false)
  const [deferredPrompt, setDeferredPrompt] = useState<BeforeInstallPromptEvent | null>(null)

  useEffect(() => {
    setTimeout(() => {
      setShowNotification(true)
    }, 3000)

    const handler = (e: Event) => {
      e.preventDefault()
      setDeferredPrompt(e as BeforeInstallPromptEvent)
    }

    window.addEventListener("beforeinstallprompt", handler)

    return () => {
      window.removeEventListener("beforeinstallprompt", handler)
    }
  }, [])

  useEffect(() => {
    if (showNotification) {
      const timer = setTimeout(() => {
        setShowNotification(false)
      }, 4000)
      return () => clearTimeout(timer)
    }
  }, [showNotification])

  const handleInstall = async () => {
    if (deferredPrompt) {
      deferredPrompt.prompt()
      const { outcome } = await deferredPrompt.userChoice
      setDeferredPrompt(null)
      setShowNotification(false)
    } else {
      const isIOS = /iPad|iPhone|iPod/.test(navigator.userAgent)
      const isAndroid = /Android/.test(navigator.userAgent)

      let instructions = "Para instalar:\n\n"
      if (isIOS) {
        instructions += "1. Toca el botón compartir (□↑)\n2. Selecciona 'Agregar a pantalla de inicio'"
      } else if (isAndroid) {
        instructions += "1. Toca el menú (⋮)\n2. Selecciona 'Instalar aplicación' o 'Agregar a pantalla de inicio'"
      } else {
        instructions += "1. Busca la opción de menú\n2. Selecciona 'Instalar aplicación'"
      }

      alert(instructions)
    }
  }

  const handleClose = () => {
    setShowNotification(false)
  }

  if (!showNotification) {
    return null
  }

  return (
    <div className="fixed bottom-4 left-1/2 -translate-x-1/2 z-50 w-[calc(100%-2rem)] max-w-md animate-in slide-in-from-bottom-5">
      <div className="bg-primary text-primary-foreground rounded-lg shadow-lg p-4 flex items-center gap-3">
        <Download className="h-5 w-5 flex-shrink-0" />
        <div className="flex-1 min-w-0">
          <p className="text-sm font-medium">Instala Inspectify CG</p>
          <p className="text-xs opacity-90">Acceso rápido desde tu dispositivo</p>
        </div>
        <Button size="sm" variant="secondary" onClick={handleInstall} className="flex-shrink-0 text-xs">
          Instalar
        </Button>
        <Button
          size="sm"
          variant="ghost"
          onClick={handleClose}
          className="flex-shrink-0 h-8 w-8 p-0 hover:bg-primary-foreground/10"
        >
          <X className="h-4 w-4" />
        </Button>
      </div>
    </div>
  )
}
