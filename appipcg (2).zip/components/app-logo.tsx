import Image from "next/image"

export function AppLogo({ className = "" }: { className?: string }) {
  return (
    <div className={`flex items-center gap-2 md:gap-3 ${className}`}>
      <Image
        src="/inspectify-logo.png"
        alt="Inspectify CG"
        width={120}
        height={40}
        className="h-8 md:h-10 w-auto object-contain flex-shrink-0"
        priority
      />
      <span className="text-base md:text-xl lg:text-2xl font-bold text-white tracking-tight whitespace-nowrap">
        Inspectify CG
      </span>
    </div>
  )
}
