"use client"

import type React from "react"

import { Download } from "lucide-react"
import { Button } from "@/components/ui/button"

interface ChartDownloadButtonProps {
  chartRef: React.RefObject<HTMLDivElement>
  fileName?: string
}

export function ChartDownloadButton({ chartRef, fileName = "chart" }: ChartDownloadButtonProps) {
  const handleDownload = async () => {
    if (!chartRef.current) return

    try {
      const { default: html2canvas } = await import("html2canvas")

      const clonedElement = chartRef.current.cloneNode(true) as HTMLElement

      // Remover todos los estilos que usen oklch() y reemplazarlos con colores sólidos
      const style = document.createElement("style")
      style.textContent = `
        * {
          color: inherit !important;
          background-color: inherit !important;
          border-color: inherit !important;
          fill: inherit !important;
          stroke: inherit !important;
        }
      `
      clonedElement.appendChild(style)

      // Crear un contenedor temporal para el elemento clonado
      const tempContainer = document.createElement("div")
      tempContainer.style.position = "absolute"
      tempContainer.style.left = "-9999px"
      tempContainer.style.top = "-9999px"
      tempContainer.style.width = chartRef.current.offsetWidth + "px"
      tempContainer.style.height = chartRef.current.offsetHeight + "px"
      tempContainer.appendChild(clonedElement)
      document.body.appendChild(tempContainer)

      try {
        const canvas = await html2canvas(clonedElement, {
          backgroundColor: "#ffffff",
          scale: 2,
          logging: false,
          allowTaint: true,
          useCORS: true,
          foreignObjectRendering: true,
        })

        const link = document.createElement("a")
        link.href = canvas.toDataURL("image/png")
        link.download = `${fileName}-${new Date().getTime()}.png`
        link.click()
      } finally {
        document.body.removeChild(tempContainer)
      }
    } catch (error) {
      console.error("Error downloading chart:", error)
      alert("Error al descargar el gráfico. Por favor intenta de nuevo.")
    }
  }

  return (
    <Button
      onClick={handleDownload}
      size="sm"
      variant="outline"
      className="h-8 w-8 p-0 bg-transparent"
      title="Descargar como PNG"
    >
      <Download className="h-4 w-4" />
    </Button>
  )
}
