import Image from "next/image"

interface LoadingScreenProps {
  message?: string
}

export function LoadingScreen({ message = "Cargando..." }: LoadingScreenProps) {
  return (
    <div className="min-h-screen bg-white flex items-center justify-center p-4">
      <div className="text-center">
        <div className="mb-8 flex justify-center">
          <Image
            src="/inspectify-logo.png"
            alt="Inspectify CG"
            width={400}
            height={90}
            className="w-full max-w-md h-auto animate-pulse"
            priority
          />
        </div>
        <div className="flex items-center justify-center gap-2">
          <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-primary"></div>
          <p className="text-base md:text-lg text-muted-foreground font-medium">{message}</p>
        </div>
      </div>
    </div>
  )
}
