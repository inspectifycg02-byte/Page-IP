// Service Worker desactivado temporalmente debido a problemas de MIME type
// La PWA funciona correctamente solo con manifest.json
