"use client"

import { useState, useEffect } from "react"
import { useParams, useRouter } from "next/navigation"
import { ArrowLeft, Download, Loader2 } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { getInspectionByIdAction, getAreasAction, getChecklistsAction } from "@/lib/actions"
import type { Inspection, Area, Checklist } from "@/lib/types"
import { generateInspectionPDF } from "@/lib/pdf-generator"
import { calculateInspectionStats } from "@/lib/utils-inspection"
import Link from "next/link"
import { useToast } from "@/hooks/use-toast"

export default function InformePage() {
  const params = useParams()
  const router = useRouter()
  const { toast } = useToast()
  const inspectionId = params.inspectionId as string

  const [inspection, setInspection] = useState<Inspection | null>(null)
  const [area, setArea] = useState<Area | null>(null)
  const [checklist, setChecklist] = useState<Checklist | null>(null)
  const [isGeneratingPDF, setIsGeneratingPDF] = useState(false)

  useEffect(() => {
    const loadData = async () => {
      try {
        const [foundInspection, areas, checklists] = await Promise.all([
          getInspectionByIdAction(inspectionId),
          getAreasAction(),
          getChecklistsAction(),
        ])

        if (!foundInspection) {
          router.push("/")
          return
        }

        const foundArea = areas.find((a) => a.id === foundInspection.areaId)
        const foundChecklist = checklists.find((c) => c.id === foundInspection.checklistId)

        setInspection(foundInspection)
        setArea(foundArea || null)
        setChecklist(foundChecklist || null)
      } catch (error) {
        console.error("[v0] Error loading data:", error)
        toast({
          title: "Error",
          description: "No se pudieron cargar los datos",
          variant: "destructive",
        })
      }
    }

    loadData()
  }, [inspectionId, router, toast])

  const handleGeneratePDF = async () => {
    if (!inspection || !area || !checklist) {
      toast({
        title: "Error",
        description: "Faltan datos necesarios para generar el informe",
        variant: "destructive",
      })
      return
    }

    setIsGeneratingPDF(true)
    try {
      console.log("[v0] Iniciando generación de PDF...")
      await generateInspectionPDF(inspection, area, checklist)
      console.log("[v0] PDF generado exitosamente")

      toast({
        title: "PDF generado",
        description: "El informe PDF ha sido descargado correctamente",
      })
    } catch (error) {
      console.error("[v0] Error al generar PDF:", error)
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "No se pudo generar el PDF",
        variant: "destructive",
      })
    } finally {
      setIsGeneratingPDF(false)
    }
  }

  if (!inspection || !area || !checklist) return null

  const stats = calculateInspectionStats(inspection, checklist)

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border bg-[#054078]">
        <div className="container mx-auto px-3 md:px-4 py-3 md:py-4">
          <div className="flex items-center gap-2 md:gap-4">
            <Link href={`/resultados/${inspectionId}`}>
              <Button
                variant="ghost"
                size="sm"
                className="h-9 w-9 p-0 md:h-10 md:w-10 bg-white text-[#054078] hover:bg-white/90"
              >
                <ArrowLeft className="h-4 w-4" />
              </Button>
            </Link>
            <div className="flex-1 min-w-0">
              <h1 className="text-lg md:text-2xl font-bold text-white truncate">Generar Informe</h1>
              <p className="text-xs md:text-sm text-white/80 truncate">Descarga el informe PDF de la inspección</p>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-3 md:px-4 py-4 md:py-8 max-w-4xl">
        <Card className="mb-6 md:mb-8">
          <CardHeader className="px-4 md:px-6">
            <CardTitle className="flex items-center gap-2 text-base md:text-lg">
              <Download className="h-4 w-4 md:h-5 md:w-5" />
              Vista Previa del Informe
            </CardTitle>
            <CardDescription className="text-xs md:text-sm">
              El informe incluirá toda la información de la inspección, estadísticas y hallazgos con fotos
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4 md:space-y-6 px-4 md:px-6">
            {/* Información General */}
            <div>
              <h3 className="font-semibold text-foreground mb-2 md:mb-3 text-sm md:text-base">Información General</h3>
              <div className="grid gap-2 text-xs md:text-sm">
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Área:</span>
                  <span className="text-foreground font-medium">{area.name}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Checklist:</span>
                  <span className="text-foreground font-medium">{checklist.name}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Inspector:</span>
                  <span className="text-foreground font-medium">{inspection.inspectorName}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Fecha:</span>
                  <span className="text-foreground font-medium">
                    {new Date(inspection.date).toLocaleDateString("es-ES", {
                      year: "numeric",
                      month: "long",
                      day: "numeric",
                    })}
                  </span>
                </div>
              </div>
            </div>

            <div className="border-t border-border pt-4 md:pt-6">
              <h3 className="font-semibold text-foreground mb-2 md:mb-3 text-sm md:text-base">Estadísticas</h3>
              <div className="grid gap-2 text-xs md:text-sm">
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Total de Criterios:</span>
                  <span className="text-foreground font-medium">{stats.totalCriteria}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Total de Hallazgos:</span>
                  <span className="text-foreground font-medium">{stats.totalFindings}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Porcentaje de Hallazgos:</span>
                  <span className="text-foreground font-medium">{stats.findingsPercentage.toFixed(1)}%</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Hallazgos Resueltos:</span>
                  <span className="text-green-500 font-medium">{stats.resolvedFindings}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Hallazgos Pendientes:</span>
                  <span className="text-yellow-500 font-medium">
                    {stats.pendingFindings + stats.inProgressFindings}
                  </span>
                </div>
              </div>
            </div>

            <div className="border-t border-border pt-4 md:pt-6">
              <h3 className="font-semibold text-foreground mb-2 md:mb-3 text-sm md:text-base">Contenido del Informe</h3>
              <ul className="space-y-2 text-xs md:text-sm text-muted-foreground">
                <li className="flex items-center gap-2">
                  <div className="h-1.5 w-1.5 rounded-full bg-primary" />
                  Información general de la inspección
                </li>
                <li className="flex items-center gap-2">
                  <div className="h-1.5 w-1.5 rounded-full bg-primary" />
                  Estadísticas completas y métricas clave
                </li>
                <li className="flex items-center gap-2">
                  <div className="h-1.5 w-1.5 rounded-full bg-primary" />
                  Tabla de hallazgos por categoría
                </li>
                <li className="flex items-center gap-2">
                  <div className="h-1.5 w-1.5 rounded-full bg-primary" />
                  Detalle completo de cada hallazgo con fotos
                </li>
                <li className="flex items-center gap-2">
                  <div className="h-1.5 w-1.5 rounded-full bg-primary" />
                  Estado y acciones correctivas
                </li>
              </ul>
            </div>
          </CardContent>
        </Card>

        <div className="flex flex-col sm:flex-row gap-3 md:gap-4">
          <Button
            onClick={handleGeneratePDF}
            disabled={isGeneratingPDF}
            className="h-12 md:h-auto text-sm md:text-base w-full sm:w-auto"
            size="lg"
          >
            {isGeneratingPDF ? (
              <>
                <Loader2 className="h-4 w-4 md:h-5 md:w-5 animate-spin mr-2" />
                <span>Generando PDF...</span>
              </>
            ) : (
              <>
                <Download className="h-4 w-4 md:h-5 md:w-5 mr-2" />
                <span>Descargar Informe PDF</span>
              </>
            )}
          </Button>
          <Link href={`/resultados/${inspectionId}`} className="flex-1">
            <Button variant="outline" className="w-full bg-transparent h-12 md:h-auto text-sm md:text-base" size="lg">
              Volver a Resultados
            </Button>
          </Link>
        </div>
      </main>
    </div>
  )
}
