"use client"

// La PWA funcionará solo con manifest.json, que es suficiente para instalación
export function RegisterServiceWorker() {
  // Service Worker desactivado temporalmente
  // La app sigue siendo instalable mediante el manifest.json
  return null
}
