import type React from "react"
import type { Metadata } from "next"
import { Inter } from "next/font/google"
import { FirstTimeLoader } from "@/components/first-time-loader"
import "./globals.css"
import { Suspense } from "react"
import { RegisterServiceWorker } from "@/app/register-sw"

const inter = Inter({
  subsets: ["latin"],
  variable: "--font-sans",
  display: "swap",
})

export const metadata: Metadata = {
  title: "Inspectify CG - Gestión de Calidad",
  description: "Sistema de gestión de calidad profesional",
  manifest: "/api/manifest",
  themeColor: "#1A2440",
  appleWebApp: {
    capable: true,
    statusBarStyle: "default",
    title: "Inspectify CG",
  },
  viewport: {
    width: "device-width",
    initialScale: 1,
    maximumScale: 1,
  },
  icons: {
    icon: [
      { url: "/favicon.ico", sizes: "any" },
      { url: "/icon-192.jpg", sizes: "192x192", type: "image/jpeg" },
      { url: "/icon-512.jpg", sizes: "512x512", type: "image/jpeg" },
    ],
    apple: [{ url: "/icon-192.jpg", sizes: "192x192", type: "image/jpeg" }],
  },
    generator: 'v0.app'
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="es">
      <head>
        <link rel="icon" href="/logo.jpg" />
        <link rel="apple-touch-icon" href="/icon-192.jpg" />
        <meta name="mobile-web-app-capable" content="yes" />
        <meta name="apple-mobile-web-app-capable" content="yes" />
        <meta name="apple-mobile-web-app-status-bar-style" content="default" />
        <meta name="apple-mobile-web-app-title" content="Inspectify CG" />
      </head>
      <body className={`font-sans ${inter.variable}`}>
        <RegisterServiceWorker />
        <Suspense fallback={null}>
          <FirstTimeLoader>{children}</FirstTimeLoader>
        </Suspense>
      </body>
    </html>
  )
}
