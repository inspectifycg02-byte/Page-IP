"use client"

import type React from "react"

import { useState } from "react"
import { ArrowLeft, Download, Upload, Database, AlertTriangle, Trash2, CheckCircle2, XCircle } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { exportDataAction, importDataAction, clearAllDataAction } from "@/lib/actions"
import Link from "next/link"
import { useToast } from "@/hooks/use-toast"
import { useRouter } from "next/navigation"
import { AppLogo } from "@/components/app-logo"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Badge } from "@/components/ui/badge"

interface ValidationResult {
  isValid: boolean
  errors: string[]
  warnings: string[]
  stats: {
    areas: number
    checklists: number
    inspections: number
    findings: number
    categories: number
    criteria: number
  }
  data: string
}

export default function RespaldoPage() {
  const { toast } = useToast()
  const router = useRouter()
  const [isExporting, setIsExporting] = useState(false)
  const [isImporting, setIsImporting] = useState(false)
  const [validationResult, setValidationResult] = useState<ValidationResult | null>(null)
  const [showValidationDialog, setShowValidationDialog] = useState(false)

  const handleExport = async () => {
    setIsExporting(true)
    try {
      const data = await exportDataAction()
      const blob = new Blob([data], { type: "application/json" })
      const url = URL.createObjectURL(blob)
      const a = document.createElement("a")
      a.href = url
      a.download = `inspectify-backup-${new Date().toISOString().split("T")[0]}.json`
      document.body.appendChild(a)
      a.click()
      document.body.removeChild(a)
      URL.revokeObjectURL(url)

      toast({
        title: "Respaldo exportado",
        description: "El archivo de respaldo ha sido descargado correctamente",
      })
    } catch (error) {
      console.error("[v0] Error al exportar:", error)
      toast({
        title: "Error",
        description: "No se pudo exportar el respaldo",
        variant: "destructive",
      })
    } finally {
      setIsExporting(false)
    }
  }

  const validateBackupData = (data: string): ValidationResult => {
    const errors: string[] = []
    const warnings: string[] = []
    const stats = {
      areas: 0,
      checklists: 0,
      inspections: 0,
      findings: 0,
      categories: 0,
      criteria: 0,
    }

    try {
      // Parse JSON
      const parsed = JSON.parse(data)

      // Validate structure
      if (!parsed || typeof parsed !== "object") {
        errors.push("El archivo no tiene una estructura JSON válida")
        return { isValid: false, errors, warnings, stats, data }
      }

      // Check required tables
      const requiredTables = ["areas", "checklists", "categories", "criteria"]
      const missingTables = requiredTables.filter((table) => !parsed[table])

      if (missingTables.length > 0) {
        errors.push(`Faltan las siguientes tablas requeridas: ${missingTables.join(", ")}`)
      }

      // Validate and count areas
      if (parsed.areas) {
        if (!Array.isArray(parsed.areas)) {
          errors.push("La tabla 'areas' debe ser un array")
        } else {
          stats.areas = parsed.areas.length
          parsed.areas.forEach((area: any, index: number) => {
            if (!area.id) errors.push(`Área ${index + 1}: falta el campo 'id'`)
            if (!area.name || typeof area.name !== "string") {
              errors.push(`Área ${index + 1}: falta o es inválido el campo 'name'`)
            }
          })
        }
      }

      // Validate and count checklists
      if (parsed.checklists) {
        if (!Array.isArray(parsed.checklists)) {
          errors.push("La tabla 'checklists' debe ser un array")
        } else {
          stats.checklists = parsed.checklists.length
          parsed.checklists.forEach((checklist: any, index: number) => {
            if (!checklist.id) errors.push(`Checklist ${index + 1}: falta el campo 'id'`)
            if (!checklist.name) errors.push(`Checklist ${index + 1}: falta el campo 'name'`)
            if (!checklist.area_id) warnings.push(`Checklist ${index + 1}: no tiene área asignada`)
          })
        }
      }

      // Validate and count categories
      if (parsed.categories) {
        if (!Array.isArray(parsed.categories)) {
          errors.push("La tabla 'categories' debe ser un array")
        } else {
          stats.categories = parsed.categories.length
          parsed.categories.forEach((category: any, index: number) => {
            if (!category.id) errors.push(`Categoría ${index + 1}: falta el campo 'id'`)
            if (!category.name) errors.push(`Categoría ${index + 1}: falta el campo 'name'`)
          })
        }
      }

      // Validate and count criteria
      if (parsed.criteria) {
        if (!Array.isArray(parsed.criteria)) {
          errors.push("La tabla 'criteria' debe ser un array")
        } else {
          stats.criteria = parsed.criteria.length
          parsed.criteria.forEach((criterion: any, index: number) => {
            if (!criterion.id) errors.push(`Criterio ${index + 1}: falta el campo 'id'`)
            if (!criterion.name) errors.push(`Criterio ${index + 1}: falta el campo 'name'`)
          })
        }
      }

      // Count inspections
      if (parsed.inspections && Array.isArray(parsed.inspections)) {
        stats.inspections = parsed.inspections.length
      }

      // Count findings
      if (parsed.findings && Array.isArray(parsed.findings)) {
        stats.findings = parsed.findings.length
      }

      // Check for empty backup
      if (stats.areas === 0 && stats.checklists === 0) {
        warnings.push("El respaldo está vacío (no contiene áreas ni checklists)")
      }

      // Check file size
      const sizeInMB = new Blob([data]).size / (1024 * 1024)
      if (sizeInMB > 10) {
        warnings.push(
          `El archivo es muy grande (${sizeInMB.toFixed(2)} MB). La importación puede tardar varios minutos`,
        )
      }

      return {
        isValid: errors.length === 0,
        errors,
        warnings,
        stats,
        data,
      }
    } catch (error) {
      errors.push(`Error al analizar el archivo: ${error instanceof Error ? error.message : "Error desconocido"}`)
      return { isValid: false, errors, warnings, stats, data }
    }
  }

  const handleImport = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0]
    if (!file) return

    setIsImporting(true)
    const reader = new FileReader()

    reader.onload = async (e) => {
      try {
        const data = e.target?.result as string

        // Validate data
        const validation = validateBackupData(data)
        setValidationResult(validation)
        setShowValidationDialog(true)
        setIsImporting(false)
      } catch (error) {
        console.error("[v0] Error al leer archivo:", error)
        toast({
          title: "Error",
          description: "No se pudo leer el archivo",
          variant: "destructive",
        })
        setIsImporting(false)
      }
    }

    reader.onerror = () => {
      toast({
        title: "Error",
        description: "No se pudo leer el archivo",
        variant: "destructive",
      })
      setIsImporting(false)
    }

    reader.readAsText(file)

    // Reset file input
    event.target.value = ""
  }

  const handleConfirmImport = async () => {
    if (!validationResult || !validationResult.isValid) return

    setIsImporting(true)
    setShowValidationDialog(false)

    try {
      await importDataAction(validationResult.data)

      toast({
        title: "Respaldo importado",
        description: "Los datos han sido restaurados correctamente",
      })

      // Recargar la página para reflejar los cambios
      setTimeout(() => {
        router.push("/")
      }, 1000)
    } catch (error) {
      console.error("[v0] Error al importar:", error)
      toast({
        title: "Error",
        description: "No se pudo importar el respaldo",
        variant: "destructive",
      })
    } finally {
      setIsImporting(false)
      setValidationResult(null)
    }
  }

  const handleClearAllData = async () => {
    try {
      await clearAllDataAction()
      toast({
        title: "Datos eliminados",
        description: "Todos los datos han sido eliminados correctamente",
      })
      setTimeout(() => {
        router.push("/")
      }, 1000)
    } catch (error) {
      console.error("[v0] Error al eliminar datos:", error)
      toast({
        title: "Error",
        description: "No se pudieron eliminar los datos",
        variant: "destructive",
      })
    }
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border bg-[#054078]">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center gap-4">
            <Link href="/">
              <Button variant="ghost" size="sm" className="h-10 w-10 p-0 bg-white text-[#054078] hover:bg-white/90">
                <ArrowLeft className="h-4 w-4" />
              </Button>
            </Link>
            <AppLogo />
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-8 max-w-4xl">
        <Alert className="mb-8">
          <AlertTriangle className="h-4 w-4" />
          <AlertTitle>Importante</AlertTitle>
          <AlertDescription>
            El respaldo incluye todas las áreas, checklists e inspecciones. Al importar un respaldo, se sobrescribirán
            todos los datos actuales. Asegúrate de exportar un respaldo antes de importar.
          </AlertDescription>
        </Alert>

        <div className="grid gap-6 md:grid-cols-2">
          {/* Export Card */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Download className="h-5 w-5" />
                Exportar Respaldo
              </CardTitle>
              <CardDescription>Descarga todos tus datos en un archivo JSON</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2 text-sm text-muted-foreground">
                <p>El respaldo incluye:</p>
                <ul className="list-disc list-inside space-y-1 ml-2">
                  <li>Todas las áreas creadas</li>
                  <li>Todos los checklists</li>
                  <li>Todas las inspecciones realizadas</li>
                  <li>Todos los hallazgos y sus fotos</li>
                </ul>
              </div>

              <Button onClick={handleExport} disabled={isExporting} className="w-full" size="lg">
                {isExporting ? (
                  <>Exportando...</>
                ) : (
                  <>
                    <Download className="mr-2 h-5 w-5" />
                    Descargar Respaldo
                  </>
                )}
              </Button>

              <p className="text-xs text-muted-foreground text-center">
                Se descargará un archivo JSON con todos tus datos
              </p>
            </CardContent>
          </Card>

          {/* Import Card */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Upload className="h-5 w-5" />
                Importar Respaldo
              </CardTitle>
              <CardDescription>Restaura tus datos desde un archivo de respaldo</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2 text-sm text-muted-foreground">
                <p>Al importar un respaldo:</p>
                <ul className="list-disc list-inside space-y-1 ml-2">
                  <li>Se validará la estructura del archivo</li>
                  <li>Se verificará la integridad de los datos</li>
                  <li>Se mostrará un resumen antes de importar</li>
                  <li>Se sobrescribirán todos los datos actuales</li>
                </ul>
              </div>

              <div>
                <input
                  type="file"
                  accept=".json"
                  onChange={handleImport}
                  className="hidden"
                  id="import-file"
                  disabled={isImporting}
                />
                <label htmlFor="import-file">
                  <Button asChild variant="outline" className="w-full bg-transparent" size="lg" disabled={isImporting}>
                    <span>
                      {isImporting ? (
                        <>Validando...</>
                      ) : (
                        <>
                          <Upload className="mr-2 h-5 w-5" />
                          Seleccionar Archivo
                        </>
                      )}
                    </span>
                  </Button>
                </label>
              </div>

              <p className="text-xs text-muted-foreground text-center">Selecciona un archivo JSON de respaldo válido</p>
            </CardContent>
          </Card>

          <Card className="border-destructive">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-destructive">
                <Trash2 className="h-5 w-5" />
                Eliminar Todos los Datos
              </CardTitle>
              <CardDescription>Borra permanentemente toda la información de la aplicación</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2 text-sm text-muted-foreground">
                <p className="text-destructive font-semibold">¡Advertencia! Esta acción:</p>
                <ul className="list-disc list-inside space-y-1 ml-2">
                  <li>Eliminará todas las áreas</li>
                  <li>Eliminará todos los checklists</li>
                  <li>Eliminará todas las inspecciones</li>
                  <li>No se puede deshacer</li>
                </ul>
              </div>

              <AlertDialog>
                <AlertDialogTrigger asChild>
                  <Button variant="destructive" className="w-full" size="lg">
                    <Trash2 className="mr-2 h-5 w-5" />
                    Eliminar Todos los Datos
                  </Button>
                </AlertDialogTrigger>
                <AlertDialogContent>
                  <AlertDialogHeader>
                    <AlertDialogTitle>¿Estás completamente seguro?</AlertDialogTitle>
                    <AlertDialogDescription>
                      Esta acción no se puede deshacer. Esto eliminará permanentemente todas las áreas, checklists e
                      inspecciones de tu dispositivo. Asegúrate de haber exportado un respaldo si deseas conservar tus
                      datos.
                    </AlertDialogDescription>
                  </AlertDialogHeader>
                  <AlertDialogFooter>
                    <AlertDialogCancel>Cancelar</AlertDialogCancel>
                    <AlertDialogAction
                      onClick={handleClearAllData}
                      className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
                    >
                      Sí, eliminar todo
                    </AlertDialogAction>
                  </AlertDialogFooter>
                </AlertDialogContent>
              </AlertDialog>

              <p className="text-xs text-muted-foreground text-center">Exporta un respaldo antes de eliminar</p>
            </CardContent>
          </Card>
        </div>

        {/* Info Card */}
        <Card className="mt-8">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Database className="h-5 w-5" />
              Información sobre Respaldos
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4 text-sm text-muted-foreground">
            <div>
              <h4 className="font-semibold text-foreground mb-2">¿Cuándo debo hacer un respaldo?</h4>
              <ul className="list-disc list-inside space-y-1 ml-2">
                <li>Antes de importar datos de otro dispositivo</li>
                <li>Periódicamente para proteger tu información</li>
                <li>Antes de realizar cambios importantes</li>
                <li>Al cambiar de dispositivo o navegador</li>
              </ul>
            </div>

            <div>
              <h4 className="font-semibold text-foreground mb-2">¿Dónde se guardan mis datos?</h4>
              <p>
                Todos los datos se almacenan en la base de datos de Supabase. Esto significa que tus datos están seguros
                y disponibles desde cualquier dispositivo donde inicies sesión.
              </p>
            </div>

            <div>
              <h4 className="font-semibold text-foreground mb-2">Recomendaciones</h4>
              <ul className="list-disc list-inside space-y-1 ml-2">
                <li>Guarda los archivos de respaldo en un lugar seguro</li>
                <li>Realiza respaldos regularmente</li>
                <li>Verifica que el archivo se descargó correctamente</li>
                <li>No edites manualmente los archivos de respaldo</li>
              </ul>
            </div>
          </CardContent>
        </Card>
      </main>

      <Dialog open={showValidationDialog} onOpenChange={setShowValidationDialog}>
        <DialogContent className="max-w-2xl max-h-[80vh]">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              {validationResult?.isValid ? (
                <>
                  <CheckCircle2 className="h-5 w-5 text-green-600" />
                  Validación Exitosa
                </>
              ) : (
                <>
                  <XCircle className="h-5 w-5 text-destructive" />
                  Errores de Validación
                </>
              )}
            </DialogTitle>
            <DialogDescription>
              {validationResult?.isValid
                ? "El archivo de respaldo es válido y está listo para importar"
                : "Se encontraron errores en el archivo de respaldo"}
            </DialogDescription>
          </DialogHeader>

          <ScrollArea className="max-h-[50vh]">
            <div className="space-y-4">
              {/* Statistics */}
              <div>
                <h4 className="font-semibold mb-2">Resumen del Respaldo</h4>
                <div className="grid grid-cols-2 gap-2">
                  <div className="flex items-center justify-between p-2 bg-muted rounded">
                    <span className="text-sm">Áreas:</span>
                    <Badge variant="secondary">{validationResult?.stats.areas || 0}</Badge>
                  </div>
                  <div className="flex items-center justify-between p-2 bg-muted rounded">
                    <span className="text-sm">Checklists:</span>
                    <Badge variant="secondary">{validationResult?.stats.checklists || 0}</Badge>
                  </div>
                  <div className="flex items-center justify-between p-2 bg-muted rounded">
                    <span className="text-sm">Categorías:</span>
                    <Badge variant="secondary">{validationResult?.stats.categories || 0}</Badge>
                  </div>
                  <div className="flex items-center justify-between p-2 bg-muted rounded">
                    <span className="text-sm">Criterios:</span>
                    <Badge variant="secondary">{validationResult?.stats.criteria || 0}</Badge>
                  </div>
                  <div className="flex items-center justify-between p-2 bg-muted rounded">
                    <span className="text-sm">Inspecciones:</span>
                    <Badge variant="secondary">{validationResult?.stats.inspections || 0}</Badge>
                  </div>
                  <div className="flex items-center justify-between p-2 bg-muted rounded">
                    <span className="text-sm">Hallazgos:</span>
                    <Badge variant="secondary">{validationResult?.stats.findings || 0}</Badge>
                  </div>
                </div>
              </div>

              {/* Errors */}
              {validationResult && validationResult.errors.length > 0 && (
                <div>
                  <h4 className="font-semibold mb-2 text-destructive flex items-center gap-2">
                    <XCircle className="h-4 w-4" />
                    Errores ({validationResult.errors.length})
                  </h4>
                  <div className="space-y-1">
                    {validationResult.errors.map((error, index) => (
                      <div key={index} className="text-sm p-2 bg-destructive/10 text-destructive rounded">
                        {error}
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Warnings */}
              {validationResult && validationResult.warnings.length > 0 && (
                <div>
                  <h4 className="font-semibold mb-2 text-yellow-600 flex items-center gap-2">
                    <AlertTriangle className="h-4 w-4" />
                    Advertencias ({validationResult.warnings.length})
                  </h4>
                  <div className="space-y-1">
                    {validationResult.warnings.map((warning, index) => (
                      <div key={index} className="text-sm p-2 bg-yellow-50 text-yellow-800 rounded">
                        {warning}
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          </ScrollArea>

          <DialogFooter>
            <Button variant="outline" onClick={() => setShowValidationDialog(false)}>
              Cancelar
            </Button>
            {validationResult?.isValid && (
              <Button onClick={handleConfirmImport} disabled={isImporting}>
                {isImporting ? "Importando..." : "Confirmar Importación"}
              </Button>
            )}
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}
