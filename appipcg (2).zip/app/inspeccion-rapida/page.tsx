"use client"

import type React from "react"

import { useState, useRef } from "react"
import { ArrowLeft, Camera, X, Download, FileText, Loader2 } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Badge } from "@/components/ui/badge"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog"
import Link from "next/link"
import { AppLogo } from "@/components/app-logo"
import { useToast } from "@/hooks/use-toast"
import { PieChart, Pie, Cell, ResponsiveContainer } from "recharts"
import { ChartContainer } from "@/components/ui/chart"
import { ChartDownloadButton } from "@/components/chart-download-button"
import JSZip from "jszip"
import { PhotoEditor } from "@/components/photo-editor"
import { generateQuickInspectionPDF } from "@/lib/pdf-generator"

interface QuickPhoto {
  id: string
  dataUrl: string
  type: "hallazgo" | "evidencia"
  description: string
}

export default function InspeccionRapidaPage() {
  const { toast } = useToast()
  const [lugar, setLugar] = useState("")
  const [inspector, setInspector] = useState("")
  const [responsable, setResponsable] = useState("")
  const [photos, setPhotos] = useState<QuickPhoto[]>([])
  const [showPhotoEditor, setShowPhotoEditor] = useState(false)
  const [currentPhotoForEdit, setCurrentPhotoForEdit] = useState<string | null>(null)
  const [isGeneratingPDF, setIsGeneratingPDF] = useState(false)
  const [isDownloadingZip, setIsDownloadingZip] = useState(false)
  const [showPDFConfirm, setShowPDFConfirm] = useState(false)
  const [showZipConfirm, setShowZipConfirm] = useState(false)
  const [showEditConfirmDialog, setShowEditConfirmDialog] = useState(false)
  const [pendingPhotoDataUrl, setPendingPhotoDataUrl] = useState<string | null>(null)
  const [pendingPhotoIsCamera, setPendingPhotoIsCamera] = useState(false)

  const pieChartRef = useRef<HTMLDivElement>(null)

  const handlePhotoCapture = (event: React.ChangeEvent<HTMLInputElement>) => {
    const files = event.target.files
    if (!files || files.length === 0) return

    const isCamera =
      (event.target as HTMLInputElement).id.includes("photo-input") &&
      (event.target as HTMLInputElement).getAttribute("capture") === "environment"

    if (files.length === 1) {
      const file = files[0]
      const reader = new FileReader()
      reader.onload = (e) => {
        const dataUrl = e.target?.result as string
        setPendingPhotoDataUrl(dataUrl)
        setPendingPhotoIsCamera(isCamera)
        setShowEditConfirmDialog(true)
        event.target.value = ""
      }
      reader.readAsDataURL(file)
    } else {
      Array.from(files).forEach((file) => {
        const reader = new FileReader()
        reader.onload = (e) => {
          const dataUrl = e.target?.result as string
          const newPhoto: QuickPhoto = {
            id: `photo_${Date.now()}_${Math.random()}`,
            dataUrl: dataUrl,
            type: "evidencia",
            description: "",
          }
          setPhotos((prev) => [...prev, newPhoto])

          if (isCamera) {
            downloadPhoto(dataUrl, `foto_${Date.now()}.jpg`)
          }
        }
        reader.readAsDataURL(file)
      })
      event.target.value = ""
    }
  }

  const handlePhotoEdited = (editedDataUrl: string) => {
    const newPhoto: QuickPhoto = {
      id: `photo_${Date.now()}_${Math.random()}`,
      dataUrl: editedDataUrl,
      type: "evidencia",
      description: "",
    }
    setPhotos((prev) => [...prev, newPhoto])

    if (pendingPhotoIsCamera) {
      downloadPhoto(editedDataUrl, `foto_editada_${Date.now()}.jpg`)
    }

    setShowPhotoEditor(false)
    setCurrentPhotoForEdit(null)
    setPendingPhotoIsCamera(false)
  }

  const handleUseOriginalPhoto = () => {
    if (!pendingPhotoDataUrl) return

    const newPhoto: QuickPhoto = {
      id: `photo_${Date.now()}_${Math.random()}`,
      dataUrl: pendingPhotoDataUrl,
      type: "evidencia",
      description: "",
    }
    setPhotos((prev) => [...prev, newPhoto])

    if (pendingPhotoIsCamera) {
      downloadPhoto(pendingPhotoDataUrl, `foto_${Date.now()}.jpg`)
    }

    setShowEditConfirmDialog(false)
    setPendingPhotoDataUrl(null)
    setPendingPhotoIsCamera(false)

    toast({
      title: "Foto agregada",
      description: "La foto se agregó correctamente",
    })
  }

  const handleOpenEditor = () => {
    if (!pendingPhotoDataUrl) return

    setCurrentPhotoForEdit(pendingPhotoDataUrl)
    setShowEditConfirmDialog(false)
    setShowPhotoEditor(true)
    setPendingPhotoDataUrl(null)
  }

  const handleRemovePhoto = (id: string) => {
    setPhotos((prev) => prev.filter((p) => p.id !== id))
  }

  const handleToggleType = (id: string) => {
    setPhotos((prev) =>
      prev.map((p) => (p.id === id ? { ...p, type: p.type === "hallazgo" ? "evidencia" : "hallazgo" } : p)),
    )
  }

  const handleDescriptionChange = (id: string, description: string) => {
    setPhotos((prev) => prev.map((p) => (p.id === id ? { ...p, description } : p)))
  }

  const hallazgos = photos.filter((p) => p.type === "hallazgo")
  const evidencias = photos.filter((p) => p.type === "evidencia")
  const totalPhotos = photos.length
  const cumplimientoPercentage = totalPhotos > 0 ? (evidencias.length / totalPhotos) * 100 : 100

  const chartData = [
    {
      name: "Cumplimiento",
      value: evidencias.length,
      fill: "#22c55e",
    },
    {
      name: "No Cumplimiento",
      value: hallazgos.length,
      fill: "#ef4444",
    },
  ]

  const handleDownloadZip = async () => {
    if (photos.length === 0) {
      toast({
        title: "Sin fotos",
        description: "No hay fotos para descargar",
        variant: "destructive",
      })
      return
    }

    setIsDownloadingZip(true)

    try {
      const zip = new JSZip()
      const dateStr = new Date().toLocaleDateString("es-ES").replace(/\//g, "-")
      const zipFileName = `Inspeccion-Rapida_${lugar || "Sin-Lugar"}_${dateStr}`

      const rootFolder = zip.folder(zipFileName)
      if (!rootFolder) return

      // Carpeta de Hallazgos
      if (hallazgos.length > 0) {
        const hallazgosFolder = rootFolder.folder("Hallazgos")
        if (hallazgosFolder) {
          for (let i = 0; i < hallazgos.length; i++) {
            const photo = hallazgos[i]
            const matches = photo.dataUrl.match(/^data:([^;]+);base64,(.+)$/)
            if (matches) {
              const mimeType = matches[1]
              const base64Data = matches[2]
              const byteCharacters = atob(base64Data)
              const byteNumbers = new Array(byteCharacters.length)
              for (let j = 0; j < byteCharacters.length; j++) {
                byteNumbers[j] = byteCharacters.charCodeAt(j)
              }
              const byteArray = new Uint8Array(byteNumbers)
              const blob = new Blob([byteArray], { type: mimeType })

              let extension = "jpg"
              if (mimeType.includes("png")) extension = "png"
              else if (mimeType.includes("jpeg") || mimeType.includes("jpg")) extension = "jpg"
              else if (mimeType.includes("webp")) extension = "webp"

              hallazgosFolder.file(`hallazgo_${i + 1}.${extension}`, blob, { binary: true })
            }
          }
        }
      }

      // Carpeta de Evidencias
      if (evidencias.length > 0) {
        const evidenciasFolder = rootFolder.folder("Evidencias")
        if (evidenciasFolder) {
          for (let i = 0; i < evidencias.length; i++) {
            const photo = evidencias[i]
            const matches = photo.dataUrl.match(/^data:([^;]+);base64,(.+)$/)
            if (matches) {
              const mimeType = matches[1]
              const base64Data = matches[2]
              const byteCharacters = atob(base64Data)
              const byteNumbers = new Array(byteCharacters.length)
              for (let j = 0; j < byteCharacters.length; j++) {
                byteNumbers[j] = byteCharacters.charCodeAt(j)
              }
              const byteArray = new Uint8Array(byteNumbers)
              const blob = new Blob([byteArray], { type: mimeType })

              let extension = "jpg"
              if (mimeType.includes("png")) extension = "png"
              else if (mimeType.includes("jpeg") || mimeType.includes("jpg")) extension = "jpg"
              else if (mimeType.includes("webp")) extension = "webp"

              evidenciasFolder.file(`evidencia_${i + 1}.${extension}`, blob, { binary: true })
            }
          }
        }
      }

      const content = await zip.generateAsync({
        type: "blob",
        compression: "DEFLATE",
        compressionOptions: {
          level: 6,
        },
      })

      const url = URL.createObjectURL(content)
      const link = document.createElement("a")
      link.href = url
      link.download = `${zipFileName}.zip`
      document.body.appendChild(link)
      link.click()
      document.body.removeChild(link)
      URL.revokeObjectURL(url)

      toast({
        title: "ZIP descargado",
        description: `Se descargaron ${photos.length} fotos correctamente`,
      })
    } catch (error) {
      console.error("[v0] Error al generar ZIP:", error)
      toast({
        title: "Error",
        description: "Error al generar el archivo ZIP",
        variant: "destructive",
      })
    } finally {
      setIsDownloadingZip(false)
      setShowZipConfirm(false)
    }
  }

  const handleGeneratePDF = async () => {
    if (!lugar || !inspector) {
      toast({
        title: "Campos requeridos",
        description: "Por favor completa el lugar e inspector",
        variant: "destructive",
      })
      return
    }

    const hallazgosSinDescripcion = hallazgos.filter((h) => !h.description.trim())
    if (hallazgosSinDescripcion.length > 0) {
      toast({
        title: "Descripción requerida",
        description: "Todos los hallazgos deben tener una descripción",
        variant: "destructive",
      })
      return
    }

    setIsGeneratingPDF(true)

    try {
      await generateQuickInspectionPDF({
        lugar,
        inspector,
        responsable,
        fecha: new Date().toISOString(),
        hallazgos: hallazgos.map((h) => ({
          descripcion: h.description,
          fotos: [h.dataUrl],
        })),
        evidencias: evidencias.map((e) => e.dataUrl),
      })

      toast({
        title: "✓ PDF generado",
        description: "El informe ha sido descargado correctamente",
      })
    } catch (error) {
      console.error("[v0] Error al generar PDF:", error)
      toast({
        title: "Error",
        description: "No se pudo generar el PDF",
        variant: "destructive",
      })
    } finally {
      setIsGeneratingPDF(false)
      setShowPDFConfirm(false)
    }
  }

  const downloadPhoto = (dataUrl: string, fileName: string) => {
    try {
      const link = document.createElement("a")
      link.href = dataUrl
      link.download = fileName
      document.body.appendChild(link)
      link.click()
      document.body.removeChild(link)
    } catch (error) {
      console.error("[v0] Error al descargar foto:", error)
    }
  }

  return (
    <div className="min-h-screen bg-background">
      <header className="border-b border-border bg-[#054078]">
        <div className="container mx-auto px-3 md:px-4 py-3 md:py-4">
          <div className="flex items-center justify-between gap-2">
            <div className="flex items-center gap-2 md:gap-4 flex-1 min-w-0">
              <Link href="/">
                <Button variant="ghost" size="sm" className="h-9 w-9 p-0 bg-white text-[#054078] hover:bg-white/90">
                  <ArrowLeft className="h-4 w-4" />
                </Button>
              </Link>
              <AppLogo />
            </div>
            {photos.length > 0 && (
              <div className="flex gap-2">
                <Button
                  onClick={() => setShowZipConfirm(true)}
                  disabled={isDownloadingZip}
                  variant="ghost"
                  size="sm"
                  className="h-9 w-9 p-0 bg-white text-[#054078] hover:bg-white/90"
                  title="Descargar ZIP"
                >
                  {isDownloadingZip ? <Loader2 className="h-4 w-4 animate-spin" /> : <Download className="h-4 w-4" />}
                </Button>
                <Button
                  onClick={() => setShowPDFConfirm(true)}
                  disabled={isGeneratingPDF}
                  variant="ghost"
                  size="sm"
                  className="h-9 w-9 p-0 bg-white text-[#054078] hover:bg-white/90"
                  title="Generar Informe PDF"
                >
                  {isGeneratingPDF ? <Loader2 className="h-4 w-4 animate-spin" /> : <FileText className="h-4 w-4" />}
                </Button>
              </div>
            )}
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8 max-w-6xl">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-foreground mb-2">Inspección Rápida</h1>
          <p className="text-muted-foreground">
            Captura fotos y clasifícalas como hallazgos o evidencias para generar un informe rápido
          </p>
        </div>

        <div className="grid gap-6 lg:grid-cols-2">
          <div className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Información de la Inspección</CardTitle>
                <CardDescription>Completa los datos básicos</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="lugar">Lugar a Inspeccionar *</Label>
                  <Input
                    id="lugar"
                    placeholder="Ej: Almacén Principal"
                    value={lugar}
                    onChange={(e) => setLugar(e.target.value)}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="inspector">Inspector *</Label>
                  <Input
                    id="inspector"
                    placeholder="Nombre del inspector"
                    value={inspector}
                    onChange={(e) => setInspector(e.target.value)}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="responsable">Responsable</Label>
                  <Input
                    id="responsable"
                    placeholder="Nombre del responsable (opcional)"
                    value={responsable}
                    onChange={(e) => setResponsable(e.target.value)}
                  />
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Captura de Evidencias</CardTitle>
                <CardDescription>Toma fotos y clasifícalas</CardDescription>
              </CardHeader>
              <CardContent>
                <input
                  type="file"
                  accept="image/*"
                  capture="environment"
                  onChange={handlePhotoCapture}
                  className="hidden"
                  id="photo-input"
                  multiple
                />
                <label htmlFor="photo-input">
                  <Button asChild className="w-full" size="lg">
                    <span>
                      <Camera className="mr-2 h-5 w-5" />
                      Tomar Foto
                    </span>
                  </Button>
                </label>

                <div className="mt-4 text-sm text-muted-foreground">
                  <p>Total de fotos: {photos.length}</p>
                  <p className="text-green-600">Evidencias: {evidencias.length}</p>
                  <p className="text-red-600">Hallazgos: {hallazgos.length}</p>
                </div>
              </CardContent>
            </Card>

            {photos.length > 0 && (
              <Card>
                <CardHeader className="flex flex-row items-center justify-between">
                  <div>
                    <CardTitle>Resumen de Cumplimiento</CardTitle>
                    <CardDescription>Distribución de evidencias y hallazgos</CardDescription>
                  </div>
                  <ChartDownloadButton chartRef={pieChartRef} fileName="resumen-cumplimiento" />
                </CardHeader>
                <CardContent>
                  <div ref={pieChartRef} className="max-h-[400px] overflow-y-auto">
                    <div className="flex flex-col items-center">
                      <ChartContainer
                        config={{
                          cumplimiento: {
                            label: "Cumplimiento",
                            color: "#22c55e",
                          },
                          noCumplimiento: {
                            label: "No Cumplimiento",
                            color: "#ef4444",
                          },
                        }}
                        className="h-[250px] w-full max-w-[300px]"
                      >
                        <ResponsiveContainer width="100%" height="100%">
                          <PieChart>
                            <Pie
                              data={chartData}
                              cx="50%"
                              cy="50%"
                              innerRadius={60}
                              outerRadius={100}
                              startAngle={90}
                              endAngle={450}
                              dataKey="value"
                              stroke="none"
                            >
                              {chartData.map((entry, index) => (
                                <Cell key={`cell-${index}`} fill={entry.fill} />
                              ))}
                            </Pie>
                            <text
                              x="50%"
                              y="50%"
                              textAnchor="middle"
                              dominantBaseline="middle"
                              className="fill-foreground font-bold"
                              style={{ fontSize: "36px" }}
                            >
                              {Math.round(cumplimientoPercentage)}%
                            </text>
                          </PieChart>
                        </ResponsiveContainer>
                      </ChartContainer>

                      <div className="mt-4 space-y-2 w-full">
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-2">
                            <div className="h-4 w-4 rounded-full bg-green-500" />
                            <span className="text-sm font-semibold">Cumplimiento</span>
                          </div>
                          <span className="text-sm font-bold">
                            {evidencias.length} ({cumplimientoPercentage.toFixed(1)}%)
                          </span>
                        </div>
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-2">
                            <div className="h-4 w-4 rounded-full bg-red-500" />
                            <span className="text-sm font-semibold">No Cumplimiento</span>
                          </div>
                          <span className="text-sm font-bold">
                            {hallazgos.length} ({(100 - cumplimientoPercentage).toFixed(1)}%)
                          </span>
                        </div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            )}
          </div>

          <div>
            <Card>
              <CardHeader>
                <CardTitle>Fotos Capturadas ({photos.length})</CardTitle>
                <CardDescription>Clasifica cada foto como hallazgo o evidencia</CardDescription>
              </CardHeader>
              <CardContent>
                {photos.length === 0 ? (
                  <div className="text-center py-12 text-muted-foreground">
                    <Camera className="h-12 w-12 mx-auto mb-4 opacity-50" />
                    <p>No hay fotos capturadas</p>
                    <p className="text-sm">Toma fotos para comenzar</p>
                  </div>
                ) : (
                  <div className="space-y-4 max-h-[800px] overflow-y-auto">
                    {photos.map((photo) => (
                      <div key={photo.id} className="border border-border rounded-lg p-4 space-y-3">
                        <div className="flex items-start justify-between gap-2">
                          <Badge
                            variant={photo.type === "hallazgo" ? "destructive" : "default"}
                            className="cursor-pointer"
                            onClick={() => handleToggleType(photo.id)}
                          >
                            {photo.type === "hallazgo" ? "Hallazgo" : "Evidencia"}
                          </Badge>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => handleRemovePhoto(photo.id)}
                            className="h-8 w-8 p-0"
                          >
                            <X className="h-4 w-4" />
                          </Button>
                        </div>

                        <img
                          src={photo.dataUrl || "/placeholder.svg"}
                          alt="Foto capturada"
                          className="w-full h-48 object-cover rounded-md"
                        />

                        <Textarea
                          placeholder={
                            photo.type === "hallazgo"
                              ? "Descripción del hallazgo (obligatorio)"
                              : "Descripción (opcional)"
                          }
                          value={photo.description}
                          onChange={(e) => handleDescriptionChange(photo.id, e.target.value)}
                          className="min-h-[60px]"
                          required={photo.type === "hallazgo"}
                        />

                        <p className="text-xs text-muted-foreground">
                          {photo.type === "hallazgo"
                            ? "La descripción es obligatoria para hallazgos"
                            : "Haz clic en la etiqueta para cambiar entre Hallazgo y Evidencia"}
                        </p>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <AlertDialog open={showPDFConfirm} onOpenChange={setShowPDFConfirm}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Generar Informe PDF</AlertDialogTitle>
            <AlertDialogDescription>
              Se generará un informe completo con {hallazgos.length} hallazgos y {evidencias.length} evidencias. ¿Deseas
              continuar?
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancelar</AlertDialogCancel>
            <AlertDialogAction onClick={handleGeneratePDF}>Generar PDF</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      <AlertDialog open={showZipConfirm} onOpenChange={setShowZipConfirm}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Descargar ZIP</AlertDialogTitle>
            <AlertDialogDescription>
              Se descargarán {photos.length} fotos organizadas en carpetas (Hallazgos: {hallazgos.length}, Evidencias:{" "}
              {evidencias.length}). ¿Deseas continuar?
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancelar</AlertDialogCancel>
            <AlertDialogAction onClick={handleDownloadZip}>Descargar ZIP</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      <AlertDialog open={showEditConfirmDialog} onOpenChange={setShowEditConfirmDialog}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>¿Editar la foto?</AlertDialogTitle>
            <AlertDialogDescription>
              Puedes agregar anotaciones (círculos, flechas, texto) o usar la foto tal como está
            </AlertDialogDescription>
          </AlertDialogHeader>
          {pendingPhotoDataUrl && (
            <div className="py-4">
              <img
                src={pendingPhotoDataUrl || "/placeholder.svg"}
                alt="Vista previa"
                className="w-full h-48 object-cover rounded-lg border"
              />
            </div>
          )}
          <AlertDialogFooter>
            <AlertDialogCancel onClick={() => setPendingPhotoDataUrl(null)}>Cancelar</AlertDialogCancel>
            <Button variant="outline" onClick={handleUseOriginalPhoto}>
              Usar Original
            </Button>
            <AlertDialogAction onClick={handleOpenEditor}>Editar Foto</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {currentPhotoForEdit && (
        <PhotoEditor
          imageUrl={currentPhotoForEdit}
          isOpen={showPhotoEditor}
          onClose={() => {
            setShowPhotoEditor(false)
            setCurrentPhotoForEdit(null)
          }}
          onSave={handlePhotoEdited}
        />
      )}
    </div>
  )
}
