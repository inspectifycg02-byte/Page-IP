"use client"

import type React from "react"

import { useState, useEffect, useRef } from "react"
import { useParams, useRouter } from "next/navigation"
import { ArrowLeft, Plus, Check, X, Trash2, Camera, Loader2, ChevronLeft, ChevronRight } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { getAreasAction, getChecklistByIdAction, saveInspectionAction, uploadPhotosAction } from "@/lib/actions"
import type { Area, Checklist, Inspection, Finding } from "@/lib/types"
import { generateInspectionId, generateFindingId } from "@/lib/utils-inspection"
import { useToast } from "@/hooks/use-toast"
import { downloadPhotoToDevice, generatePhotoFileName } from "@/lib/photo-utils"
import { PhotoEditor } from "@/components/photo-editor"

type FindingStatus = "conforme" | "no-conforme" | "pendiente"

interface GroupedCategory {
  name: string
  items: Array<{ id: string; criterion: string; subcriterion?: string; details?: string }>
}

export default function InspectionPage() {
  const params = useParams()
  const router = useRouter()
  const { toast } = useToast()
  const areaId = params.areaId as string
  const checklistId = params.checklistId as string

  const [area, setArea] = useState<Area | null>(null)
  const [checklist, setChecklist] = useState<Checklist | null>(null)
  const [inspectorName, setInspectorName] = useState("")
  const [currentInspection, setCurrentInspection] = useState<Inspection | null>(null)
  const [groupedCategories, setGroupedCategories] = useState<GroupedCategory[]>([])

  const [criteriaStates, setCriteriaStates] = useState<
    Record<
      string,
      {
        status: FindingStatus | null
        description: string
        photos: string[]
      }
    >
  >({})

  const [uploadingPhotos, setUploadingPhotos] = useState<Record<string, boolean>>({})
  const [uploadProgress, setUploadProgress] = useState<Record<string, { current: number; total: number }>>({})
  const [showConfirmDialog, setShowConfirmDialog] = useState(false)
  const [isSaving, setIsSaving] = useState(false)

  const [photoEditorOpen, setPhotoEditorOpen] = useState(false)
  const [currentEditingPhoto, setCurrentEditingPhoto] = useState<string>("")
  const [currentEditingCriterionId, setCurrentEditingCriterionId] = useState<string>("")

  const [compressingPhotos, setCompressingPhotos] = useState<Record<string, boolean>>({})
  const [compressionProgress, setCompressionProgress] = useState<Record<string, { current: number; total: number }>>({})

  const [activeCategory, setActiveCategory] = useState<string>("")
  const categoryRefs = useRef<Record<string, HTMLDivElement | null>>({})

  const tabsContainerRef = useRef<HTMLDivElement>(null)
  const [canScrollLeft, setCanScrollLeft] = useState(false)
  const [canScrollRight, setCanScrollRight] = useState(false)

  const [showEditConfirmDialog, setShowEditConfirmDialog] = useState(false)
  const [pendingPhotoData, setPendingPhotoData] = useState<{
    dataUrl: string
    criterionId: string
    isCamera?: boolean
  } | null>(null)

  useEffect(() => {
    const loadData = async () => {
      try {
        const areas = await getAreasAction()
        const foundArea = areas.find((a) => a.id === areaId)
        if (!foundArea) {
          router.push("/")
          return
        }

        const foundChecklist = await getChecklistByIdAction(checklistId)
        if (!foundChecklist || !foundChecklist.items) {
          router.push(`/area/${areaId}`)
          return
        }

        setArea(foundArea)
        setChecklist(foundChecklist)

        const grouped: Record<string, GroupedCategory> = {}

        foundChecklist.items.forEach((item) => {
          if (!grouped[item.category]) {
            grouped[item.category] = {
              name: item.category,
              items: [],
            }
          }
          grouped[item.category].items.push({
            id: item.id,
            criterion: item.criterion,
            subcriterion: item.subcriterion,
            details: item.details,
          })
        })

        const categoriesArray = Object.values(grouped)
        setGroupedCategories(categoriesArray)

        if (categoriesArray.length > 0) {
          setActiveCategory(categoriesArray[0].name)
        }

        const newInspection: Inspection = {
          id: generateInspectionId(),
          areaId,
          checklistId,
          date: new Date().toISOString(),
          findings: [],
          inspectorName: "",
          status: "en-progreso",
        }
        setCurrentInspection(newInspection)
      } catch (error) {
        console.error("Error loading inspection data:", error)
        toast({
          title: "Error",
          description: "No se pudieron cargar los datos de la inspección",
          variant: "destructive",
        })
      }
    }

    loadData()
  }, [areaId, checklistId, router, toast])

  const checkScroll = () => {
    if (tabsContainerRef.current) {
      const { scrollLeft, scrollWidth, clientWidth } = tabsContainerRef.current
      setCanScrollLeft(scrollLeft > 0)
      setCanScrollRight(scrollLeft < scrollWidth - clientWidth - 10)
    }
  }

  useEffect(() => {
    checkScroll()
    window.addEventListener("resize", checkScroll)
    return () => window.removeEventListener("resize", checkScroll)
  }, [groupedCategories])

  const scrollTabs = (direction: "left" | "right") => {
    if (tabsContainerRef.current) {
      const scrollAmount = 200
      tabsContainerRef.current.scrollBy({
        left: direction === "left" ? -scrollAmount : scrollAmount,
        behavior: "smooth",
      })
      setTimeout(checkScroll, 300)
    }
  }

  const handleStatusChange = (criterionId: string, status: FindingStatus) => {
    setCriteriaStates((prev) => ({
      ...prev,
      [criterionId]: {
        ...prev[criterionId],
        status,
        description: prev[criterionId]?.description || "",
        photos: prev[criterionId]?.photos || [],
      },
    }))
  }

  const handleDescriptionChange = (criterionId: string, description: string) => {
    setCriteriaStates((prev) => ({
      ...prev,
      [criterionId]: {
        ...prev[criterionId],
        description,
        status: prev[criterionId]?.status || null,
        photos: prev[criterionId]?.photos || [],
      },
    }))
  }

  const handlePhotoUpload = async (criterionId: string, event: React.ChangeEvent<HTMLInputElement>) => {
    const files = event.target.files
    if (!files || files.length === 0) return

    const isCamera = (event.target as HTMLInputElement).id.includes("camera")

    if (files.length > 50) {
      toast({
        title: "Demasiadas fotos",
        description: "Por favor sube máximo 50 fotos a la vez. Puedes hacer múltiples subidas.",
        variant: "destructive",
      })
      event.target.value = ""
      return
    }

    if (files.length === 1) {
      const file = files[0]

      const reader = new FileReader()
      reader.onload = () => {
        const dataUrl = reader.result as string
        setPendingPhotoData({ dataUrl, criterionId, isCamera })
        setShowEditConfirmDialog(true)
        event.target.value = ""
      }
      reader.readAsDataURL(file)
      return
    }

    const totalFiles = files.length
    console.log(`[v0] Processing ${totalFiles} photos from ${isCamera ? "camera" : "gallery"}...`)

    setCompressingPhotos((prev) => ({ ...prev, [criterionId]: true }))
    setCompressionProgress((prev) => ({ ...prev, [criterionId]: { current: 0, total: totalFiles } }))

    try {
      const { compressMultipleImages } = await import("@/lib/image-compression")

      const base64Images = await compressMultipleImages(Array.from(files), (current, total) => {
        setCompressionProgress((prev) => ({
          ...prev,
          [criterionId]: { current, total },
        }))
      })

      console.log(`[v0] Compressed ${base64Images.length} images successfully`)

      for (let i = 0; i < base64Images.length; i++) {
        const photoFileName = generatePhotoFileName("evidencia", (criteriaStates[criterionId]?.photos?.length || 0) + i)
        downloadPhotoToDevice(base64Images[i], photoFileName)
      }

      setCompressingPhotos((prev) => {
        const newState = { ...prev }
        delete newState[criterionId]
        return newState
      })

      if (isCamera) {
        setUploadingPhotos((prev) => ({ ...prev, [criterionId]: true }))
        setUploadProgress((prev) => ({ ...prev, [criterionId]: { current: 0, total: base64Images.length } }))

        console.log(`[v0] Uploading ${base64Images.length} photos from camera to Blob...`)

        const BATCH_SIZE = 10
        const photoUrls: string[] = []

        for (let i = 0; i < base64Images.length; i += BATCH_SIZE) {
          const batch = base64Images.slice(i, i + BATCH_SIZE)
          console.log(
            `[v0] Uploading batch ${Math.floor(i / BATCH_SIZE) + 1} of ${Math.ceil(base64Images.length / BATCH_SIZE)}...`,
          )

          try {
            const batchUrls = await uploadPhotosAction(batch)
            photoUrls.push(...batchUrls)

            setUploadProgress((prev) => ({
              ...prev,
              [criterionId]: { current: photoUrls.length, total: base64Images.length },
            }))
          } catch (error) {
            console.error(`[v0] Error uploading batch:`, error)
            toast({
              title: "Advertencia",
              description: `Algunas fotos del lote ${Math.floor(i / BATCH_SIZE) + 1} no se pudieron subir`,
              variant: "destructive",
            })
          }
        }

        console.log(`[v0] Successfully uploaded ${photoUrls.length} of ${base64Images.length} photos`)

        setCriteriaStates((prev) => ({
          ...prev,
          [criterionId]: {
            ...prev[criterionId],
            photos: [...(prev[criterionId]?.photos || []), ...photoUrls],
            status: prev[criterionId]?.status || null,
            description: prev[criterionId]?.description || "",
          },
        }))

        toast({
          title: "Fotos agregadas",
          description: `Se agregaron ${photoUrls.length} foto(s) correctamente${photoUrls.length < base64Images.length ? ` (${base64Images.length - photoUrls.length} fallaron)` : ""}`,
        })
      } else {
        console.log(`[v0] Using ${base64Images.length} photos from gallery directly (no upload)`)

        setCriteriaStates((prev) => ({
          ...prev,
          [criterionId]: {
            ...prev[criterionId],
            photos: [...(prev[criterionId]?.photos || []), ...base64Images],
            status: prev[criterionId]?.status || null,
            description: prev[criterionId]?.description || "",
          },
        }))

        toast({
          title: "Fotos agregadas",
          description: `Se agregaron ${base64Images.length} foto(s) de galería correctamente`,
        })
      }
    } catch (error) {
      console.error("[v0] Error uploading photos:", error)
      toast({
        title: "Error",
        description: "No se pudieron cargar las fotos. Intenta con menos imágenes a la vez.",
        variant: "destructive",
      })
    } finally {
      setCompressingPhotos((prev) => {
        const newState = { ...prev }
        delete newState[criterionId]
        return newState
      })
      setCompressionProgress((prev) => {
        const newState = { ...prev }
        delete newState[criterionId]
        return newState
      })
      setUploadingPhotos((prev) => {
        const newState = { ...prev }
        delete newState[criterionId]
        return newState
      })
      setUploadProgress((prev) => {
        const newState = { ...prev }
        delete newState[criterionId]
        return newState
      })
      event.target.value = ""
    }
  }

  const handleSaveEditedPhoto = async (editedImageUrl: string) => {
    const criterionId = currentEditingCriterionId
    const isCamera = pendingPhotoData?.isCamera ?? true

    if (isCamera) {
      setUploadingPhotos((prev) => ({ ...prev, [criterionId]: true }))
      setUploadProgress((prev) => ({ ...prev, [criterionId]: { current: 0, total: 1 } }))

      try {
        const photoFileName = generatePhotoFileName("evidencia", criteriaStates[criterionId]?.photos?.length || 0)
        downloadPhotoToDevice(editedImageUrl, photoFileName)

        setUploadProgress((prev) => ({
          ...prev,
          [criterionId]: { current: 1, total: 1 },
        }))

        console.log("[v0] Uploading edited photo from camera to Blob Storage...")
        const photoUrls = await uploadPhotosAction([editedImageUrl])
        console.log("[v0] Photo uploaded successfully:", photoUrls[0])

        setCriteriaStates((prev) => ({
          ...prev,
          [criterionId]: {
            ...prev[criterionId],
            photos: [...(prev[criterionId]?.photos || []), ...photoUrls],
            status: prev[criterionId]?.status || null,
            description: prev[criterionId]?.description || "",
          },
        }))

        toast({
          title: "Foto agregada",
          description: "La foto editada se agregó correctamente",
        })
      } catch (error) {
        console.error("[v0] Error uploading edited photo:", error)
        toast({
          title: "Error",
          description: "No se pudo cargar la foto editada",
          variant: "destructive",
        })
      } finally {
        setUploadingPhotos((prev) => {
          const newState = { ...prev }
          delete newState[criterionId]
          return newState
        })
        setUploadProgress((prev) => {
          const newState = { ...prev }
          delete newState[criterionId]
          return newState
        })
        setPhotoEditorOpen(false)
        setCurrentEditingPhoto("")
        setCurrentEditingCriterionId("")
      }
    } else {
      setCriteriaStates((prev) => ({
        ...prev,
        [criterionId]: {
          ...prev[criterionId],
          photos: [...(prev[criterionId]?.photos || []), editedImageUrl],
          status: prev[criterionId]?.status || null,
          description: prev[criterionId]?.description || "",
        },
      }))

      toast({
        title: "Foto agregada",
        description: "La foto editada de galería se agregó correctamente",
      })

      setPhotoEditorOpen(false)
      setCurrentEditingPhoto("")
      setCurrentEditingCriterionId("")
    }
  }

  const handleRemovePhoto = (criterionId: string, photoIndex: number) => {
    setCriteriaStates((prev) => ({
      ...prev,
      [criterionId]: {
        ...prev[criterionId],
        photos: prev[criterionId]?.photos.filter((_, idx) => idx !== photoIndex) || [],
        status: prev[criterionId]?.status || null,
        description: prev[criterionId]?.description || "",
      },
    }))
  }

  const handleConfirmSave = () => {
    if (!inspectorName.trim()) {
      toast({
        title: "Error",
        description: "Por favor ingresa el nombre del inspector",
        variant: "destructive",
      })
      return
    }

    const isRegistroChecklist = checklist?.type === "registro"

    if (!isRegistroChecklist) {
      const invalidCriteria = Object.entries(criteriaStates).filter(([_, state]) => {
        return state.status === "no-conforme" && !state.description.trim()
      })

      if (invalidCriteria.length > 0) {
        toast({
          title: "Error",
          description: 'Los criterios "No Conforme" deben tener una descripción',
          variant: "destructive",
        })
        return
      }
    }

    setShowConfirmDialog(true)
  }

  const handleSaveInspection = async () => {
    if (!currentInspection) return

    setIsSaving(true)
    console.log("[v0] Starting to save inspection...")

    try {
      const findings: Finding[] = Object.entries(criteriaStates)
        .filter(([_, state]) => state.status !== null)
        .map(([criterionId, state]) => ({
          id: generateFindingId(),
          itemId: criterionId,
          description: state.description,
          photos: state.photos, // Ahora son URLs, no base64
          status: state.status!,
          correctiveAction: "",
          dueDate: "",
          solutionPhotos: [],
        }))

      console.log(
        `[v0] Saving inspection with ${findings.length} findings and ${findings.reduce((sum, finding) => sum + finding.photos.length, 0)} total photos (as URLs)...`,
      )

      const finalInspection: Inspection = {
        ...currentInspection,
        findings,
        inspectorName,
      }

      const result = await saveInspectionAction(finalInspection)

      if (!result.success || !result.id) {
        throw new Error(result.error || "No se pudo guardar la inspección")
      }

      console.log("[v0] Inspection saved successfully:", result.id)

      toast({
        title: "Inspección guardada",
        description: "La inspección ha sido guardada correctamente",
      })

      setShowConfirmDialog(false)
      router.push(`/resultados/${result.id}`)
    } catch (error) {
      console.error("[v0] Error saving inspection:", error)

      const errorMessage = error instanceof Error ? error.message : "Error desconocido"

      toast({
        title: "Error al guardar",
        description: errorMessage,
        variant: "destructive",
      })

      setIsSaving(false)
    }
  }

  const handleUseOriginalPhoto = async () => {
    if (!pendingPhotoData) return

    const { dataUrl, criterionId, isCamera } = pendingPhotoData

    if (isCamera) {
      setUploadingPhotos((prev) => ({ ...prev, [criterionId]: true }))
      setUploadProgress((prev) => ({ ...prev, [criterionId]: { current: 0, total: 1 } }))

      try {
        const photoFileName = generatePhotoFileName("evidencia", criteriaStates[criterionId]?.photos?.length || 0)
        downloadPhotoToDevice(dataUrl, photoFileName)

        setUploadProgress((prev) => ({
          ...prev,
          [criterionId]: { current: 1, total: 1 },
        }))

        console.log("[v0] Uploading original photo from camera to Blob Storage...")
        const photoUrls = await uploadPhotosAction([dataUrl])
        console.log("[v0] Photo uploaded successfully:", photoUrls[0])

        setCriteriaStates((prev) => ({
          ...prev,
          [criterionId]: {
            ...prev[criterionId],
            photos: [...(prev[criterionId]?.photos || []), ...photoUrls],
            status: prev[criterionId]?.status || null,
            description: prev[criterionId]?.description || "",
          },
        }))

        toast({
          title: "Foto agregada",
          description: "La foto se agregó correctamente",
        })
      } catch (error) {
        console.error("[v0] Error uploading photo:", error)
        toast({
          title: "Error",
          description: "No se pudo cargar la foto",
          variant: "destructive",
        })
      } finally {
        setUploadingPhotos((prev) => {
          const newState = { ...prev }
          delete newState[criterionId]
          return newState
        })
        setUploadProgress((prev) => {
          const newState = { ...prev }
          delete newState[criterionId]
          return newState
        })
        setShowEditConfirmDialog(false)
        setPendingPhotoData(null)
      }
    } else {
      setCriteriaStates((prev) => ({
        ...prev,
        [criterionId]: {
          ...prev[criterionId],
          photos: [...(prev[criterionId]?.photos || []), dataUrl],
          status: prev[criterionId]?.status || null,
          description: prev[criterionId]?.description || "",
        },
      }))

      toast({
        title: "Foto agregada",
        description: "La foto de galería se agregó correctamente",
      })

      setShowEditConfirmDialog(false)
      setPendingPhotoData(null)
    }
  }

  const handleOpenEditor = () => {
    if (!pendingPhotoData) return

    setCurrentEditingPhoto(pendingPhotoData.dataUrl)
    setCurrentEditingCriterionId(pendingPhotoData.criterionId)
    setShowEditConfirmDialog(false)
    setPhotoEditorOpen(true)
    setPendingPhotoData(null)
  }

  const getEvaluatedCount = (categoryName: string) => {
    const category = groupedCategories.find((c) => c.name === categoryName)
    if (!category) return { evaluated: 0, total: 0 }

    const total = category.items.length
    const evaluated = category.items.filter(
      (item) => criteriaStates[item.id]?.status !== null && criteriaStates[item.id]?.status !== undefined,
    ).length

    return { evaluated, total }
  }

  const getTotalEvaluated = () => {
    if (!checklist || !checklist.items) return { evaluated: 0, total: 0 }

    const total = checklist.items.length
    const evaluated = Object.values(criteriaStates).filter(
      (state) => state.status !== null && state.status !== undefined,
    ).length

    return { evaluated, total }
  }

  const scrollToCategory = (categoryName: string) => {
    setActiveCategory(categoryName)
    const element = categoryRefs.current[categoryName]
    if (element) {
      const headerOffset = 180 // Offset for sticky header + tabs
      const elementPosition = element.getBoundingClientRect().top
      const offsetPosition = elementPosition + window.pageYOffset - headerOffset

      window.scrollTo({
        top: offsetPosition,
        behavior: "smooth",
      })
    }
  }

  if (!area || !checklist || !currentInspection) return null

  const totalStats = getTotalEvaluated()
  const completionPercentage = totalStats.total > 0 ? (totalStats.evaluated / totalStats.total) * 100 : 0

  const isRegistroChecklist = checklist.type === "registro"

  const conformeCount = Object.values(criteriaStates).filter((s) => s.status === "conforme").length
  const noConformeCount = Object.values(criteriaStates).filter((s) => s.status === "no-conforme").length
  const totalPhotos = Object.values(criteriaStates).reduce((sum, s) => sum + (s.photos?.length || 0), 0)

  const isAnyUploading = Object.keys(uploadingPhotos).length > 0
  const isAnyCompressing = Object.keys(compressingPhotos).length > 0

  const activeCategories = groupedCategories.filter((cat) => cat.name === activeCategory)

  return (
    <div className="min-h-screen bg-background">
      <header className="border-b border-border bg-[#054078] sticky top-0 z-10">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <Button
              onClick={() => router.back()}
              variant="ghost"
              size="sm"
              className="h-10 w-10 p-0 bg-white text-[#054078] hover:bg-white/90"
            >
              <ArrowLeft className="h-4 w-4" />
            </Button>
            <div className="text-right">
              <p className="text-sm text-white/80">
                {totalStats.evaluated} de {totalStats.total}
              </p>
              <p className="text-sm font-semibold text-white">{completionPercentage.toFixed(0)}%</p>
            </div>
          </div>
          <div className="mt-4 text-center">
            <h1 className="text-xl md:text-2xl font-bold text-white">Inspección en Progreso</h1>
            <p className="text-xs md:text-sm text-white/80">
              {area.name} • {checklist.name} • {inspectorName || "Sin asignar"}
              {isRegistroChecklist && (
                <span className="ml-2 px-2 py-0.5 bg-white/20 text-white rounded text-xs font-medium">Registros</span>
              )}
            </p>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-3 md:px-4 py-4 md:py-6">
        <Card className="p-4 mb-4 md:mb-6">
          <Label htmlFor="inspector" className="text-sm font-medium">
            Nombre del Inspector
          </Label>
          <Input
            id="inspector"
            value={inspectorName}
            onChange={(e) => setInspectorName(e.target.value)}
            placeholder="Ingresa tu nombre"
            className="mt-2 h-12 text-base"
          />
        </Card>

        {groupedCategories.length > 1 && (
          <div className="sticky top-[120px] z-10 bg-background pb-4 mb-6">
            <div className="relative">
              {canScrollLeft && (
                <button
                  onClick={() => scrollTabs("left")}
                  className="absolute left-0 top-1/2 -translate-y-1/2 z-20 bg-background/80 backdrop-blur-sm p-1 rounded-full shadow-md hover:bg-background"
                >
                  <ChevronLeft className="h-5 w-5" />
                </button>
              )}

              <div
                ref={tabsContainerRef}
                onScroll={checkScroll}
                className="overflow-x-auto scrollbar-hide scroll-smooth"
              >
                <div className="flex gap-2 min-w-max pb-2 px-8">
                  {groupedCategories.map((category) => {
                    const { evaluated, total } = getEvaluatedCount(category.name)
                    const isActive = activeCategory === category.name

                    return (
                      <button
                        key={category.name}
                        onClick={() => scrollToCategory(category.name)}
                        className={`px-4 py-2.5 rounded-lg text-sm font-medium whitespace-nowrap transition-all ${
                          isActive ? "bg-[#054078] text-white shadow-md" : "bg-gray-100 text-gray-700 hover:bg-gray-200"
                        }`}
                      >
                        <div className="flex flex-col items-center gap-1">
                          <span>{category.name}</span>
                          <span className={`text-xs ${isActive ? "text-white/90" : "text-gray-500"}`}>
                            {evaluated}/{total}
                          </span>
                        </div>
                      </button>
                    )
                  })}
                </div>
              </div>

              {canScrollRight && (
                <button
                  onClick={() => scrollTabs("right")}
                  className="absolute right-0 top-1/2 -translate-y-1/2 z-20 bg-background/80 backdrop-blur-sm p-1 rounded-full shadow-md hover:bg-background"
                >
                  <ChevronRight className="h-5 w-5" />
                </button>
              )}
            </div>

            <div className="mt-3 px-8">
              <div className="relative h-2 bg-gray-200 rounded-full overflow-hidden">
                <div
                  className="absolute top-0 left-0 h-full bg-[#054078] transition-all duration-300"
                  style={{ width: `${completionPercentage}%` }}
                />
              </div>
            </div>
          </div>
        )}

        <div className="space-y-6">
          {activeCategories.map((category) => {
            const { evaluated, total } = getEvaluatedCount(category.name)

            return (
              <div
                key={category.name}
                className="space-y-3 md:space-y-4"
                ref={(el) => {
                  categoryRefs.current[category.name] = el
                }}
              >
                <div className="flex items-start gap-3 mb-4">
                  <div className="w-1 h-6 bg-[#054078] rounded-full flex-shrink-0 mt-1" />
                  <div className="flex-1">
                    <h2 className="text-lg md:text-xl font-bold text-foreground">{category.name}</h2>
                  </div>
                </div>

                {category.items.map((item) => {
                  const state = criteriaStates[item.id]
                  const isNonConformeOrPending = state?.status === "no-conforme"
                  const isUploadingThis = uploadingPhotos[item.id] || false
                  const progressThis = uploadProgress[item.id] || { current: 0, total: 0 }

                  return (
                    <Card key={item.id} className="p-4 md:p-6 bg-white">
                      <div className="space-y-4">
                        <div>
                          <p className="text-sm md:text-base text-foreground leading-relaxed">{item.criterion}</p>
                          {item.subcriterion && (
                            <p className="text-xs md:text-sm text-muted-foreground mt-1">{item.subcriterion}</p>
                          )}
                          {item.details && (
                            <p className="text-xs md:text-sm text-muted-foreground mt-1">{item.details}</p>
                          )}
                        </div>

                        <div className="grid grid-cols-2 gap-3">
                          <Button
                            onClick={() => handleStatusChange(item.id, "conforme")}
                            className={`h-14 text-base font-medium transition-all border-2 ${
                              state?.status === "conforme"
                                ? "!bg-[#86d293] !text-white !border-[#86d293] hover:!bg-[#75c182]"
                                : "!bg-white !text-gray-700 !border-gray-300 hover:!bg-green-50"
                            }`}
                          >
                            <Check
                              className={`h-6 w-6 ${state?.status === "conforme" ? "text-white" : "text-[#86d293]"}`}
                            />
                          </Button>
                          <Button
                            onClick={() => handleStatusChange(item.id, "no-conforme")}
                            className={`h-14 text-base font-medium transition-all border-2 ${
                              state?.status === "no-conforme"
                                ? "!bg-[#f5a5a8] !text-white !border-[#f5a5a8] hover:!bg-[#f39499]"
                                : "!bg-white !text-gray-700 !border-gray-300 hover:!bg-red-50"
                            }`}
                          >
                            <X
                              className={`h-6 w-6 ${state?.status === "no-conforme" ? "text-white" : "text-[#f5a5a8]"}`}
                            />
                          </Button>
                        </div>

                        {isNonConformeOrPending && (
                          <div>
                            <Textarea
                              value={state?.description || ""}
                              onChange={(e) => handleDescriptionChange(item.id, e.target.value)}
                              placeholder={
                                isRegistroChecklist ? "Observaciones (opcional)..." : "Observaciones (obligatorio)..."
                              }
                              className="min-h-[100px] text-base"
                            />
                          </div>
                        )}

                        <div className="space-y-3">
                          {compressingPhotos[item.id] && compressionProgress[item.id] && (
                            <div className="flex items-center gap-2 p-3 bg-purple-50 dark:bg-purple-950 rounded-lg">
                              <Loader2 className="h-4 w-4 animate-spin text-purple-600" />
                              <span className="text-sm text-purple-600 dark:text-purple-400">
                                Comprimiendo fotos: {compressionProgress[item.id].current} de{" "}
                                {compressionProgress[item.id].total}
                              </span>
                            </div>
                          )}

                          {isUploadingThis && progressThis.total > 0 && (
                            <div className="flex items-center gap-2 p-3 bg-blue-50 dark:bg-blue-950 rounded-lg">
                              <Loader2 className="h-4 w-4 animate-spin text-blue-600" />
                              <span className="text-sm text-blue-600 dark:text-blue-400">
                                {progressThis.total === 1
                                  ? "Procesando foto..."
                                  : `Subiendo fotos: ${progressThis.current} de ${progressThis.total}`}
                              </span>
                            </div>
                          )}

                          {state?.photos && state.photos.length > 0 && (
                            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3">
                              {state.photos.map((photo, idx) => (
                                <div key={idx} className="relative group">
                                  <img
                                    src={photo || "/placeholder.svg"}
                                    alt={`Evidencia ${idx + 1}`}
                                    className="w-full aspect-square object-cover rounded-lg border border-border"
                                  />
                                  <Button
                                    variant="destructive"
                                    size="sm"
                                    className="absolute top-1 right-1 h-8 w-8 p-0 opacity-90 md:opacity-0 md:group-hover:opacity-100 transition-opacity"
                                    onClick={() => handleRemovePhoto(item.id, idx)}
                                  >
                                    <Trash2 className="h-4 w-4" />
                                  </Button>
                                </div>
                              ))}
                            </div>
                          )}

                          <div className="grid grid-cols-2 gap-3">
                            <input
                              id={`camera-${item.id}`}
                              type="file"
                              accept="image/*"
                              capture="environment"
                              multiple
                              onChange={(e) => handlePhotoUpload(item.id, e)}
                              className="hidden"
                              disabled={isUploadingThis || compressingPhotos[item.id]}
                            />
                            <label htmlFor={`camera-${item.id}`} className="block">
                              <Button
                                className="w-full h-14 cursor-pointer bg-white hover:bg-gray-50 text-sm md:text-base border-2"
                                disabled={isUploadingThis || compressingPhotos[item.id]}
                                asChild
                              >
                                <span>
                                  {isUploadingThis || compressingPhotos[item.id] ? (
                                    <Loader2 className="h-5 w-5 animate-spin" />
                                  ) : (
                                    <Camera className="h-5 w-5 text-gray-600" />
                                  )}
                                </span>
                              </Button>
                            </label>

                            <input
                              id={`gallery-${item.id}`}
                              type="file"
                              accept="image/*"
                              multiple
                              onChange={(e) => handlePhotoUpload(item.id, e)}
                              className="hidden"
                              disabled={isUploadingThis || compressingPhotos[item.id]}
                            />
                            <label htmlFor={`gallery-${item.id}`} className="block">
                              <Button
                                className="w-full h-14 cursor-pointer bg-white hover:bg-gray-50 text-sm md:text-base border-2"
                                disabled={isUploadingThis || compressingPhotos[item.id]}
                                asChild
                              >
                                <span>
                                  {isUploadingThis || compressingPhotos[item.id] ? (
                                    <Loader2 className="h-5 w-5 animate-spin" />
                                  ) : (
                                    <Plus className="h-5 w-5 text-gray-600" />
                                  )}
                                </span>
                              </Button>
                            </label>
                          </div>
                        </div>
                      </div>
                    </Card>
                  )
                })}
              </div>
            )
          })}
        </div>

        <div className="mt-6 md:mt-8 flex justify-center sticky bottom-4 md:static">
          <Button
            onClick={handleConfirmSave}
            disabled={!inspectorName.trim() || isAnyUploading || isAnyCompressing}
            size="lg"
            className="w-full md:w-auto h-14 text-base md:text-lg bg-[#5b9bd5] hover:bg-[#4a8ac4] text-white shadow-lg"
          >
            Finalizar Inspección
          </Button>
        </div>
      </main>

      <Dialog open={showConfirmDialog} onOpenChange={setShowConfirmDialog}>
        <DialogContent className="w-[95vw] max-w-md">
          <DialogHeader>
            <DialogTitle>Confirmar Finalización</DialogTitle>
            <DialogDescription>Revisa el resumen de la inspección antes de guardar</DialogDescription>
          </DialogHeader>
          <div className="py-4 space-y-4">
            <div className="space-y-2">
              <div className="flex justify-between items-center">
                <span className="text-sm text-muted-foreground">Inspector:</span>
                <span className="font-medium">{inspectorName}</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-sm text-muted-foreground">Criterios evaluados:</span>
                <span className="font-medium">
                  {totalStats.evaluated} de {totalStats.total}
                </span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-sm text-muted-foreground">Conformes:</span>
                <span className="font-medium text-green-600">{conformeCount}</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-sm text-muted-foreground">No conformes:</span>
                <span className="font-medium text-red-600">{noConformeCount}</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-sm text-muted-foreground">Total de fotos:</span>
                <span className="font-medium">{totalPhotos}</span>
              </div>
            </div>
            {totalStats.evaluated < totalStats.total && (
              <div className="p-3 bg-yellow-50 dark:bg-yellow-950 rounded-lg">
                <p className="text-sm text-yellow-800 dark:text-yellow-200">
                  ⚠️ Hay {totalStats.total - totalStats.evaluated} criterio(s) sin evaluar
                </p>
              </div>
            )}
            {totalPhotos > 20 && (
              <div className="p-3 bg-orange-50 dark:bg-orange-950 rounded-lg">
                <p className="text-sm text-orange-800 dark:text-orange-200">
                  ⚠️ Tienes {totalPhotos} fotos. El guardado puede tomar varios segundos.
                </p>
              </div>
            )}
            {isSaving && (
              <div className="flex items-center gap-3 p-4 bg-blue-50 dark:bg-blue-950 rounded-lg">
                <Loader2 className="h-5 w-5 animate-spin text-blue-600" />
                <div className="flex-1">
                  <p className="text-sm font-medium text-blue-900 dark:text-blue-100">Guardando inspección...</p>
                  <p className="text-xs text-blue-700 dark:text-blue-300 mt-1">
                    Esto puede tomar hasta un minuto con muchas fotos
                  </p>
                </div>
              </div>
            )}
          </div>
          <DialogFooter className="flex-col gap-2 sm:flex-row">
            <Button
              variant="outline"
              onClick={() => setShowConfirmDialog(false)}
              size="lg"
              className="w-full sm:w-auto"
              disabled={isSaving}
            >
              Cancelar
            </Button>
            <Button
              onClick={handleSaveInspection}
              size="lg"
              className="w-full sm:w-auto bg-[#054078] hover:bg-[#043060] text-white"
              disabled={isSaving}
            >
              {isSaving ? (
                <>
                  <Loader2 className="h-4 w-4 animate-spin mr-2" />
                  Guardando...
                </>
              ) : (
                "Confirmar y Guardar"
              )}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Dialog open={showEditConfirmDialog} onOpenChange={setShowEditConfirmDialog}>
        <DialogContent className="w-[95vw] max-w-md">
          <DialogHeader>
            <DialogTitle>¿Editar la foto?</DialogTitle>
            <DialogDescription>
              Puedes agregar anotaciones (círculos, flechas, texto) o usar la foto tal como está
            </DialogDescription>
          </DialogHeader>
          {pendingPhotoData && (
            <div className="py-4">
              <img
                src={pendingPhotoData.dataUrl || "/placeholder.svg"}
                alt="Vista previa"
                className="w-full h-48 object-cover rounded-lg border"
              />
            </div>
          )}
          <DialogFooter className="flex-col gap-2 sm:flex-row">
            <Button
              variant="outline"
              onClick={handleUseOriginalPhoto}
              size="lg"
              className="w-full sm:w-auto bg-transparent"
            >
              Usar Original
            </Button>
            <Button
              onClick={handleOpenEditor}
              size="lg"
              className="w-full sm:w-auto bg-[#054078] hover:bg-[#043060] text-white"
            >
              Editar Foto
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <PhotoEditor
        imageUrl={currentEditingPhoto}
        isOpen={photoEditorOpen}
        onClose={() => {
          setPhotoEditorOpen(false)
          setCurrentEditingPhoto("")
          setCurrentEditingCriterionId("")
        }}
        onSave={handleSaveEditedPhoto}
      />
    </div>
  )
}
