"use client"

import jsPDF from "jspdf"
import autoTable from "jspdf-autotable"
import type { Inspection, Area, Checklist } from "./types"
import { calculateInspectionStats } from "./utils-inspection"

const COLORS = {
  primary: [26, 36, 64], // #1A2440
  accent: [132, 191, 44], // #84BF2C
  conforme: [34, 197, 94], // #22c55e - verde brillante
  noConforme: [239, 68, 68], // #ef4444 - rojo
  pendiente: [245, 158, 11], // #f59e0b - naranja
  text: [50, 50, 50],
  lightGray: [240, 240, 240],
  white: [255, 255, 255],
}

async function loadAndOptimizeImage(photoUrl: string): Promise<{ dataUrl: string; width: number; height: number }> {
  return new Promise((resolve, reject) => {
    const img = new Image()
    img.crossOrigin = "anonymous"

    img.onload = () => {
      try {
        // Crear canvas para optimizar la imagen
        const canvas = document.createElement("canvas")
        const ctx = canvas.getContext("2d")

        if (!ctx) {
          reject(new Error("No se pudo crear el contexto del canvas"))
          return
        }

        // Calcular dimensiones optimizadas (máximo 1200px en el lado más largo)
        const maxSize = 1200
        let width = img.width
        let height = img.height

        if (width > height && width > maxSize) {
          height = (height * maxSize) / width
          width = maxSize
        } else if (height > maxSize) {
          width = (width * maxSize) / height
          height = maxSize
        }

        canvas.width = width
        canvas.height = height

        // Dibujar imagen optimizada
        ctx.drawImage(img, 0, 0, width, height)

        // Convertir a base64 con calidad optimizada
        const optimizedDataUrl = canvas.toDataURL("image/jpeg", 0.85)

        resolve({ dataUrl: optimizedDataUrl, width, height })
      } catch (error) {
        reject(error)
      }
    }

    img.onerror = () => {
      reject(new Error("Error al cargar la imagen"))
    }

    img.src = photoUrl
  })
}

export async function generateInspectionPDF(inspection: Inspection, area: Area, checklist: Checklist): Promise<void> {
  try {
    console.log("[v0] Iniciando generación de PDF...")
    const doc = new jsPDF()
    const stats = calculateInspectionStats(inspection, checklist)
    const compliancePercentage =
      stats.totalCriteria > 0 ? ((stats.totalCriteria - stats.totalFindings) / stats.totalCriteria) * 100 : 100

    const isRegistroChecklist = checklist.type === "registro"

    let yPosition = 20

    doc.setFillColor(...COLORS.primary)
    doc.rect(0, 0, 210, 40, "F")

    doc.setFontSize(24)
    doc.setTextColor(...COLORS.white)
    doc.text("INFORME DE INSPECCIÓN", 105, 20, { align: "center" })

    doc.setFontSize(10)
    doc.setTextColor(200, 200, 200)
    doc.text("Inspectify CG - Gestión de Calidad", 105, 30, { align: "center" })

    yPosition = 50

    doc.setFillColor(...COLORS.accent)
    doc.rect(15, yPosition, 180, 8, "F")
    doc.setFontSize(14)
    doc.setTextColor(...COLORS.white)
    doc.setFont("helvetica", "bold")
    doc.text("1. RESUMEN DE LA INSPECCIÓN", 20, yPosition + 5.5)
    doc.setFont("helvetica", "normal")
    yPosition += 13

    const summaryData = [
      ["Área", area.name],
      ["Responsable del Área", area.responsible || "No especificado"],
      ["Checklist", checklist.name],
      ["Inspector", inspection.inspectorName],
      [
        "Fecha de Inspección",
        new Date(inspection.date).toLocaleDateString("es-ES", {
          year: "numeric",
          month: "long",
          day: "numeric",
          hour: "2-digit",
          minute: "2-digit",
        }),
      ],
    ]

    autoTable(doc, {
      startY: yPosition,
      head: [],
      body: summaryData,
      theme: "plain",
      styles: {
        fontSize: 10,
        cellPadding: 3,
        textColor: COLORS.text,
      },
      columnStyles: {
        0: { fontStyle: "bold", cellWidth: 45, textColor: COLORS.primary },
        1: { cellWidth: "auto" },
      },
      margin: { left: 15, right: 15 },
    })

    yPosition = (doc as any).lastAutoTable.finalY + 15

    if (isRegistroChecklist) {
      if (yPosition > 200) {
        doc.addPage()
        yPosition = 20
      }

      doc.setFillColor(...COLORS.accent)
      doc.rect(15, yPosition, 180, 8, "F")
      doc.setFontSize(14)
      doc.setTextColor(...COLORS.white)
      doc.setFont("helvetica", "bold")
      doc.text("2. TABLA DE REGISTROS", 20, yPosition + 5.5)
      doc.setFont("helvetica", "normal")
      yPosition += 13

      const registroTableData = checklist.items.map((item) => {
        const finding = inspection.findings.find((f) => f.itemId === item.id)
        const estado = finding?.status === "no-conforme" ? "No Conforme" : "Conforme"
        return [item.criterion, estado]
      })

      autoTable(doc, {
        startY: yPosition,
        head: [["Nombre del Registro", "Estado"]],
        body: registroTableData,
        theme: "grid",
        styles: {
          fontSize: 10,
          cellPadding: 4,
          textColor: COLORS.text,
        },
        headStyles: {
          fillColor: COLORS.primary,
          textColor: [255, 255, 255],
          fontStyle: "bold",
          fontSize: 11,
        },
        columnStyles: {
          0: { cellWidth: "auto" },
          1: {
            halign: "center",
            fontStyle: "bold",
            fontSize: 11,
            cellWidth: 40,
          },
        },
        margin: { left: 15, right: 15 },
        didParseCell: (data) => {
          if (data.column.index === 1 && data.section === "body") {
            if (data.cell.text[0] === "Conforme") {
              data.cell.styles.textColor = COLORS.conforme
            } else if (data.cell.text[0] === "No Conforme") {
              data.cell.styles.textColor = COLORS.noConforme
            }
          }
        },
      })

      yPosition = (doc as any).lastAutoTable.finalY + 15
    }

    if (yPosition > 210) {
      doc.addPage()
      yPosition = 20
    }

    doc.setFillColor(...COLORS.accent)
    doc.rect(15, yPosition, 180, 8, "F")
    doc.setFontSize(14)
    doc.setTextColor(...COLORS.white)
    doc.setFont("helvetica", "bold")
    doc.text(isRegistroChecklist ? "3. GRÁFICO DE DISTRIBUCIÓN" : "2. GRÁFICOS Y ESTADÍSTICAS", 20, yPosition + 5.5)
    doc.setFont("helvetica", "normal")
    yPosition += 13

    if (!isRegistroChecklist) {
      doc.setFillColor(...COLORS.primary)
      doc.rect(15, yPosition, 180, 8, "F")
      doc.setFontSize(12)
      doc.setTextColor(...COLORS.white)
      doc.setFont("helvetica", "bold")
      doc.text("2.1 Distribución de Estados", 20, yPosition + 5.5)
      doc.setFont("helvetica", "normal")
      yPosition += 13
    }

    const conformeCount = stats.totalCriteria - stats.totalFindings
    const centerX = 60
    const centerY = yPosition + 30
    const outerRadius = 25
    const innerRadius = 15

    const conformeAngle = (conformeCount / stats.totalCriteria) * 360
    const noConformeAngle = (stats.totalFindings / stats.totalCriteria) * 360

    // Dibujar gráfico de anillos
    doc.setFillColor(...COLORS.conforme)
    drawDonutSlice(doc, centerX, centerY, outerRadius, innerRadius, 0, conformeAngle)

    doc.setFillColor(...COLORS.noConforme)
    drawDonutSlice(doc, centerX, centerY, outerRadius, innerRadius, conformeAngle, conformeAngle + noConformeAngle)

    // Centro blanco del anillo
    doc.setFillColor(...COLORS.white)
    doc.circle(centerX, centerY, innerRadius, "F")

    // Porcentaje en el centro
    doc.setFontSize(16)
    doc.setFont("helvetica", "bold")
    doc.setTextColor(...COLORS.primary)
    doc.text(`${compliancePercentage.toFixed(0)}%`, centerX, centerY + 2, { align: "center" })
    doc.setFont("helvetica", "normal")

    // Leyenda del gráfico de anillos
    const legendX = 100
    const legendY = yPosition + 15

    doc.setFillColor(...COLORS.conforme)
    doc.rect(legendX, legendY, 6, 6, "F")
    doc.setFontSize(11)
    doc.setFont("helvetica", "bold")
    doc.setTextColor(...COLORS.text)
    doc.text(
      `Conforme: ${conformeCount} (${((conformeCount / stats.totalCriteria) * 100).toFixed(1)}%)`,
      legendX + 10,
      legendY + 4.5,
    )

    doc.setFillColor(...COLORS.noConforme)
    doc.rect(legendX, legendY + 12, 6, 6, "F")
    doc.text(
      `No Conforme: ${stats.totalFindings} (${((stats.totalFindings / stats.totalCriteria) * 100).toFixed(1)}%)`,
      legendX + 10,
      legendY + 16.5,
    )
    doc.setFont("helvetica", "normal")

    yPosition += 70

    if (!isRegistroChecklist && Object.keys(stats.findingsByCategory).length > 0) {
      if (yPosition > 200) {
        doc.addPage()
        yPosition = 20
      }

      doc.setFillColor(...COLORS.primary)
      doc.rect(15, yPosition, 180, 8, "F")
      doc.setFontSize(12)
      doc.setTextColor(...COLORS.white)
      doc.setFont("helvetica", "bold")
      doc.text("2.2 Hallazgos por Categoría", 20, yPosition + 5.5)
      doc.setFont("helvetica", "normal")
      yPosition += 13

      const allCategories = Array.from(new Set(checklist.items.map((item) => item.category)))

      const categoryData = allCategories.map((category) => {
        const totalInCategory = checklist.items.filter((item) => item.category === category).length
        const count = stats.findingsByCategory[category] || 0
        const compliance = totalInCategory > 0 ? ((totalInCategory - count) / totalInCategory) * 100 : 100
        return [category, totalInCategory.toString(), count.toString(), `${compliance.toFixed(1)}%`]
      })

      autoTable(doc, {
        startY: yPosition,
        head: [["Categoría", "Total", "Hallazgos", "Cumplimiento"]],
        body: categoryData,
        theme: "grid",
        styles: {
          fontSize: 10,
          cellPadding: 4,
          textColor: COLORS.text,
        },
        headStyles: {
          fillColor: COLORS.primary,
          textColor: [255, 255, 255],
          fontStyle: "bold",
          fontSize: 11,
        },
        columnStyles: {
          0: { cellWidth: "auto" },
          1: { halign: "center", fontStyle: "bold", fontSize: 11, cellWidth: 25 },
          2: { halign: "center", fontStyle: "bold", fontSize: 11, cellWidth: 30 },
          3: { halign: "center", fontStyle: "bold", fontSize: 11, cellWidth: 35 },
        },
        margin: { left: 15, right: 15 },
      })

      yPosition = (doc as any).lastAutoTable.finalY + 15
    }

    if (!isRegistroChecklist && Object.keys(stats.findingsByCategory).length > 0) {
      if (yPosition > 220) {
        doc.addPage()
        yPosition = 20
      }

      doc.setFillColor(...COLORS.primary)
      doc.rect(15, yPosition, 180, 8, "F")
      doc.setFontSize(12)
      doc.setTextColor(...COLORS.white)
      doc.setFont("helvetica", "bold")
      doc.text("2.3 Cumplimiento por Categoría", 20, yPosition + 5.5)
      doc.setFont("helvetica", "normal")
      yPosition += 13

      const allCategories = Array.from(new Set(checklist.items.map((item) => item.category)))

      const complianceData = allCategories
        .map((category) => {
          const totalInCategory = checklist.items.filter((item) => item.category === category).length
          const findings = stats.findingsByCategory[category] || 0
          const compliance = totalInCategory > 0 ? ((totalInCategory - findings) / totalInCategory) * 100 : 100
          return {
            category,
            cumplimiento: Math.round(compliance),
          }
        })
        .sort((a, b) => a.cumplimiento - b.cumplimiento)

      const chartWidth = 100
      const barHeight = 8
      const barSpacing = 12
      const chartHeight = complianceData.length * barSpacing
      const labelWidth = 50 // Ancho estimado para las etiquetas
      const totalChartWidth = labelWidth + chartWidth + 20 // labels + barras + porcentajes
      const chartX = (210 - totalChartWidth) / 2 + labelWidth // Centrar y ajustar por las etiquetas
      const chartY = yPosition

      complianceData.forEach((data, index) => {
        const yPos = chartY + index * barSpacing

        doc.setFontSize(9)
        doc.setFont("helvetica", "normal")
        doc.setTextColor(...COLORS.text)
        const categoryLabel = data.category.length > 20 ? data.category.substring(0, 20) + "..." : data.category
        doc.text(categoryLabel, chartX - 5, yPos + barHeight / 2 + 1, { align: "right" })

        const barWidth = (data.cumplimiento / 100) * chartWidth
        doc.setFillColor(...COLORS.accent)
        doc.rect(chartX, yPos, barWidth, barHeight, "F")

        doc.setFillColor(230, 230, 230)
        doc.rect(chartX + barWidth, yPos, chartWidth - barWidth, barHeight, "F")

        doc.setFontSize(10)
        doc.setFont("helvetica", "bold")
        doc.setTextColor(...COLORS.text)
        doc.text(`${data.cumplimiento}%`, chartX + chartWidth + 3, yPos + barHeight / 2 + 1)
      })

      yPosition += chartHeight + 15
    }

    const nonConformFindings = inspection.findings.filter((f) => f.status === "no-conforme")

    if (nonConformFindings.length > 0) {
      doc.addPage()
      yPosition = 20

      doc.setFillColor(...COLORS.accent)
      doc.rect(15, yPosition, 180, 8, "F")
      doc.setFontSize(14)
      doc.setTextColor(...COLORS.white)
      doc.setFont("helvetica", "bold")
      doc.text(isRegistroChecklist ? "4. HALLAZGOS NO CONFORMES" : "4. HALLAZGOS NO CONFORMES", 20, yPosition + 5.5)
      doc.setFont("helvetica", "normal")
      yPosition += 15

      console.log("[v0] Optimizando imágenes...")
      const imageCache = new Map<string, { dataUrl: string; width: number; height: number } | null>()

      for (const finding of nonConformFindings) {
        if (finding.photos.length > 0) {
          for (const photoUrl of finding.photos) {
            if (!imageCache.has(photoUrl)) {
              try {
                const optimizedImage = await loadAndOptimizeImage(photoUrl)
                imageCache.set(photoUrl, optimizedImage)
              } catch (error) {
                console.error("[v0] Error optimizando imagen:", error)
                imageCache.set(photoUrl, null) // Marcar como error
              }
            }
          }
        }
      }
      console.log("[v0] Imágenes optimizadas:", imageCache.size)

      for (let i = 0; i < nonConformFindings.length; i++) {
        const finding = nonConformFindings[i]
        const item = checklist.items.find((it) => it.id === finding.itemId)
        if (!item) continue

        if (finding.photos.length > 0 && i > 0) {
          doc.addPage()
          yPosition = 20
        } else if (yPosition > 240) {
          // Solo agregar página si no cabe y no tiene fotos
          doc.addPage()
          yPosition = 20
        }

        const hallazgoNumber = String(i + 1).padStart(2, "0")
        doc.setFillColor(...COLORS.primary)
        doc.rect(15, yPosition, 180, 10, "F")
        doc.setFontSize(12)
        doc.setTextColor(...COLORS.white)
        doc.setFont("helvetica", "bold")
        doc.text(`Hallazgo ${hallazgoNumber}`, 105, yPosition + 6.5, { align: "center" })
        doc.setFont("helvetica", "normal")
        yPosition += 15

        const findingData = [
          ["Área", area.name],
          ["Responsable del Área", area.responsible || "No especificado"],
          ["Criterio", item.subcategory || item.criterion],
          ["Descripción", finding.description || "Sin descripción"],
        ]

        autoTable(doc, {
          startY: yPosition,
          head: [],
          body: findingData,
          theme: "grid",
          styles: {
            fontSize: 10,
            cellPadding: 4,
            textColor: COLORS.text,
          },
          columnStyles: {
            0: {
              fontStyle: "bold",
              cellWidth: 35,
              textColor: COLORS.primary,
              fillColor: COLORS.lightGray,
            },
            1: { cellWidth: "auto" },
          },
          margin: { left: 15, right: 15 },
        })

        yPosition = (doc as any).lastAutoTable.finalY + 10

        if (finding.photos.length > 0) {
          doc.setFontSize(10)
          doc.setFont("helvetica", "bold")
          doc.setTextColor(...COLORS.primary)
          doc.text("Evidencia Fotográfica:", 105, yPosition, { align: "center" })
          doc.setFont("helvetica", "normal")
          yPosition += 8

          const pageWidth = 210 // Ancho de página A4 en mm
          const margin = 20 // Márgenes laterales reducidos de 30 a 20
          const photoWidth = pageWidth - 2 * margin // 170mm de ancho (antes 150mm)
          const maxPhotoHeight = 110 // Altura máxima reducida para permitir 2 fotos por página
          const photoSpacing = 15 // Espacio entre fotos

          for (let j = 0; j < finding.photos.length; j++) {
            const photoUrl = finding.photos[j]
            const optimizedImage = imageCache.get(photoUrl)

            if (!optimizedImage) {
              // Si la imagen no se pudo cargar, mostrar mensaje
              doc.setFontSize(9)
              doc.setTextColor(150, 150, 150)
              doc.text("Error al cargar imagen", 105, yPosition + 20, { align: "center" })
              yPosition += 40
              continue
            }

            try {
              const aspectRatio = optimizedImage.height / optimizedImage.width

              if (!aspectRatio || isNaN(aspectRatio) || aspectRatio <= 0) {
                console.error("[v0] Aspect ratio inválido:", aspectRatio)
                doc.setFontSize(9)
                doc.setTextColor(150, 150, 150)
                doc.text("Error: dimensiones inválidas", 105, yPosition + 20, { align: "center" })
                yPosition += 40
                continue
              }

              let finalWidth = photoWidth
              let finalHeight = photoWidth * aspectRatio

              // Si la foto es vertical y excede la altura máxima, ajustar por altura
              if (finalHeight > maxPhotoHeight) {
                finalHeight = maxPhotoHeight
                finalWidth = maxPhotoHeight / aspectRatio
              }

              // Verificar si necesitamos nueva página
              if (yPosition + finalHeight > 270) {
                doc.addPage()
                yPosition = 20
              }

              // Centrar la imagen horizontalmente
              const xPos = margin + (photoWidth - finalWidth) / 2

              doc.addImage(optimizedImage.dataUrl, "JPEG", xPos, yPosition, finalWidth, finalHeight)

              // Borde decorativo alrededor de la imagen
              doc.setDrawColor(...COLORS.primary)
              doc.setLineWidth(0.5)
              doc.rect(xPos, yPosition, finalWidth, finalHeight)

              // Número de foto debajo de la imagen
              doc.setFontSize(8)
              doc.setTextColor(...COLORS.text)
              doc.text(`Foto ${j + 1} de ${finding.photos.length}`, 105, yPosition + finalHeight + 4, {
                align: "center",
              })

              // Avanzar posición Y con espacio entre fotos
              yPosition += finalHeight + photoSpacing
            } catch (error) {
              console.error("[v0] Error agregando imagen al PDF:", error)
              doc.setFontSize(9)
              doc.setTextColor(150, 150, 150)
              doc.text("Error al procesar imagen", 105, yPosition + 20, { align: "center" })
              yPosition += 40
            }
          }
        } else {
          doc.setFontSize(9)
          doc.setTextColor(150, 150, 150)
          doc.text("Sin evidencia fotográfica", 105, yPosition, { align: "center" })
          yPosition += 5
        }

        if (finding.photos.length === 0) {
          yPosition += 10
        }
      }
    }

    const pageCount = doc.getNumberOfPages()
    for (let i = 1; i <= pageCount; i++) {
      doc.setPage(i)
      doc.setFontSize(8)
      doc.setTextColor(150, 150, 150)
      doc.text(`Página ${i} de ${pageCount} | Generado el ${new Date().toLocaleDateString("es-ES")}`, 105, 290, {
        align: "center",
      })
    }

    const fileName = `Informe_${area.name.replace(/[^a-zA-Z0-9]/g, "_")}_${new Date(inspection.date).toLocaleDateString("es-ES").replace(/\//g, "-")}.pdf`

    console.log("[v0] Guardando PDF...")
    doc.save(fileName)

    await new Promise((resolve) => setTimeout(resolve, 500))
    console.log("[v0] PDF generado y descargado exitosamente")
  } catch (error) {
    console.error("[v0] Error generando PDF:", error)
    throw new Error("No se pudo generar el PDF. Por favor, intenta nuevamente.")
  }
}

function drawDonutSlice(
  doc: jsPDF,
  centerX: number,
  centerY: number,
  outerRadius: number,
  innerRadius: number,
  startAngle: number,
  endAngle: number,
) {
  const startRad = (startAngle * Math.PI) / 180
  const endRad = (endAngle * Math.PI) / 180

  doc.moveTo(centerX + outerRadius * Math.cos(startRad), centerY + outerRadius * Math.sin(startRad))

  for (let i = 0; i <= Math.ceil(Math.abs(endAngle - startAngle)); i++) {
    const angle = startRad + (endRad - startRad) * (i / Math.ceil(Math.abs(endAngle - startAngle)))
    const x = centerX + outerRadius * Math.cos(angle)
    const y = centerY + outerRadius * Math.sin(angle)
    doc.lineTo(x, y)
  }

  doc.lineTo(centerX + innerRadius * Math.cos(endRad), centerY + innerRadius * Math.sin(endRad))

  for (let i = Math.ceil(Math.abs(endAngle - startAngle)); i >= 0; i--) {
    const angle = startRad + (endRad - startRad) * (i / Math.ceil(Math.abs(endAngle - startAngle)))
    const x = centerX + innerRadius * Math.cos(angle)
    const y = centerY + innerRadius * Math.sin(angle)
    doc.lineTo(x, y)
  }

  doc.lineTo(centerX + outerRadius * Math.cos(startRad), centerY + outerRadius * Math.sin(startRad))
  doc.fill()
}

export async function generateQuickInspectionPDF(data: {
  lugar: string
  inspector: string
  responsable: string
  fecha: string
  evidencias: string[]
  hallazgos: Array<{ descripcion: string; fotos: string[] }>
}): Promise<void> {
  try {
    console.log("[v0] Generando PDF de inspección rápida con formato estándar...")
    const doc = new jsPDF()

    let yPosition = 20

    // Header igual que inspecciones normales
    doc.setFillColor(...COLORS.primary)
    doc.rect(0, 0, 210, 40, "F")

    doc.setFontSize(24)
    doc.setTextColor(...COLORS.white)
    doc.text("INFORME DE INSPECCIÓN", 105, 20, { align: "center" })

    doc.setFontSize(10)
    doc.setTextColor(200, 200, 200)
    doc.text("Inspectify CG - Gestión de Calidad", 105, 30, { align: "center" })

    yPosition = 50

    // Sección 1: RESUMEN DE LA INSPECCIÓN (igual que normal)
    doc.setFillColor(...COLORS.accent)
    doc.rect(15, yPosition, 180, 8, "F")
    doc.setFontSize(14)
    doc.setTextColor(...COLORS.white)
    doc.setFont("helvetica", "bold")
    doc.text("1. RESUMEN DE LA INSPECCIÓN", 20, yPosition + 5.5)
    doc.setFont("helvetica", "normal")
    yPosition += 13

    // Tabla de resumen (igual que inspecciones normales)
    const summaryData = [
      ["Área", data.lugar],
      ["Responsable del Área", data.responsable],
      ["Checklist", "Inspección Rápida"],
      ["Inspector", data.inspector],
      [
        "Fecha de Inspección",
        new Date(data.fecha).toLocaleDateString("es-ES", {
          year: "numeric",
          month: "long",
          day: "numeric",
          hour: "2-digit",
          minute: "2-digit",
        }),
      ],
    ]

    autoTable(doc, {
      startY: yPosition,
      head: [],
      body: summaryData,
      theme: "plain",
      styles: {
        fontSize: 10,
        cellPadding: 3,
        textColor: COLORS.text,
      },
      columnStyles: {
        0: { fontStyle: "bold", cellWidth: 45, textColor: COLORS.primary },
        1: { cellWidth: "auto" },
      },
      margin: { left: 15, right: 15 },
    })

    yPosition = (doc as any).lastAutoTable.finalY + 15

    if (yPosition > 210) {
      doc.addPage()
      yPosition = 20
    }

    // Sección 2: GRÁFICOS Y ESTADÍSTICAS (igual que normal)
    doc.setFillColor(...COLORS.accent)
    doc.rect(15, yPosition, 180, 8, "F")
    doc.setFontSize(14)
    doc.setTextColor(...COLORS.white)
    doc.setFont("helvetica", "bold")
    doc.text("2. GRÁFICOS Y ESTADÍSTICAS", 20, yPosition + 5.5)
    doc.setFont("helvetica", "normal")
    yPosition += 13

    // Subsección 2.1: Distribución de Estados (igual que normal)
    doc.setFillColor(...COLORS.primary)
    doc.rect(15, yPosition, 180, 8, "F")
    doc.setFontSize(12)
    doc.setTextColor(...COLORS.white)
    doc.setFont("helvetica", "bold")
    doc.text("2.1 Distribución de Estados", 20, yPosition + 5.5)
    doc.setFont("helvetica", "normal")
    yPosition += 13

    // Calcular estadísticas
    const hallazgosFotos = data.hallazgos.reduce((sum, h) => sum + h.fotos.length, 0)
    const totalFotos = data.evidencias.length + hallazgosFotos
    const conformeCount = data.evidencias.length
    const noConformeCount = hallazgosFotos
    const compliancePercentage = totalFotos > 0 ? (conformeCount / totalFotos) * 100 : 100

    // Gráfico de anillos (igual que normal)
    const centerX = 60
    const centerY = yPosition + 30
    const outerRadius = 25
    const innerRadius = 15

    const conformeAngle = totalFotos > 0 ? (conformeCount / totalFotos) * 360 : 0
    const noConformeAngle = totalFotos > 0 ? (noConformeCount / totalFotos) * 360 : 0

    if (totalFotos > 0) {
      doc.setFillColor(...COLORS.conforme)
      drawDonutSlice(doc, centerX, centerY, outerRadius, innerRadius, 0, conformeAngle)

      doc.setFillColor(...COLORS.noConforme)
      drawDonutSlice(doc, centerX, centerY, outerRadius, innerRadius, conformeAngle, conformeAngle + noConformeAngle)
    }

    // Centro blanco del anillo
    doc.setFillColor(...COLORS.white)
    doc.circle(centerX, centerY, innerRadius, "F")

    // Porcentaje en el centro
    doc.setFontSize(16)
    doc.setFont("helvetica", "bold")
    doc.setTextColor(...COLORS.primary)
    doc.text(`${compliancePercentage.toFixed(0)}%`, centerX, centerY + 2, { align: "center" })
    doc.setFont("helvetica", "normal")

    // Leyenda del gráfico (igual que normal)
    const legendX = 100
    const legendY = yPosition + 15

    doc.setFillColor(...COLORS.conforme)
    doc.rect(legendX, legendY, 6, 6, "F")
    doc.setFontSize(11)
    doc.setFont("helvetica", "bold")
    doc.setTextColor(...COLORS.text)
    doc.text(
      `Conforme: ${conformeCount} (${totalFotos > 0 ? ((conformeCount / totalFotos) * 100).toFixed(1) : 0}%)`,
      legendX + 10,
      legendY + 4.5,
    )

    doc.setFillColor(...COLORS.noConforme)
    doc.rect(legendX, legendY + 12, 6, 6, "F")
    doc.text(
      `No Conforme: ${noConformeCount} (${totalFotos > 0 ? ((noConformeCount / totalFotos) * 100).toFixed(1) : 0}%)`,
      legendX + 10,
      legendY + 16.5,
    )
    doc.setFont("helvetica", "normal")

    yPosition += 70

    // Sección 3: HALLAZGOS NO CONFORMES (renumerado de 4 a 3)
    if (data.hallazgos.length > 0) {
      doc.addPage()
      yPosition = 20

      doc.setFillColor(...COLORS.accent)
      doc.rect(15, yPosition, 180, 8, "F")
      doc.setFontSize(14)
      doc.setTextColor(...COLORS.white)
      doc.setFont("helvetica", "bold")
      doc.text("3. HALLAZGOS NO CONFORMES", 20, yPosition + 5.5)
      doc.setFont("helvetica", "normal")
      yPosition += 15

      console.log("[v0] Optimizando imágenes...")
      const imageCache = new Map<string, { dataUrl: string; width: number; height: number } | null>()

      for (const hallazgo of data.hallazgos) {
        for (const photoUrl of hallazgo.fotos) {
          if (!imageCache.has(photoUrl)) {
            try {
              const optimizedImage = await loadAndOptimizeImage(photoUrl)
              imageCache.set(photoUrl, optimizedImage)
            } catch (error) {
              console.error("[v0] Error optimizando imagen:", error)
              imageCache.set(photoUrl, null)
            }
          }
        }
      }
      console.log("[v0] Imágenes optimizadas:", imageCache.size)

      for (let i = 0; i < data.hallazgos.length; i++) {
        const hallazgo = data.hallazgos[i]

        // Si tiene fotos y no es el primero, nueva página
        if (hallazgo.fotos.length > 0 && i > 0) {
          doc.addPage()
          yPosition = 20
        } else if (yPosition > 240) {
          doc.addPage()
          yPosition = 20
        }

        // Header del hallazgo (igual que normal)
        const hallazgoNumber = String(i + 1).padStart(2, "0")
        doc.setFillColor(...COLORS.primary)
        doc.rect(15, yPosition, 180, 10, "F")
        doc.setFontSize(12)
        doc.setTextColor(...COLORS.white)
        doc.setFont("helvetica", "bold")
        doc.text(`Hallazgo ${hallazgoNumber}`, 105, yPosition + 6.5, { align: "center" })
        doc.setFont("helvetica", "normal")
        yPosition += 15

        // Tabla de información del hallazgo (igual que normal)
        const findingData = [
          ["Categoría", "Inspección Rápida"],
          ["Criterio", "Hallazgo Identificado"],
          ["Descripción", hallazgo.descripcion || "Sin descripción"],
        ]

        autoTable(doc, {
          startY: yPosition,
          head: [],
          body: findingData,
          theme: "grid",
          styles: {
            fontSize: 10,
            cellPadding: 4,
            textColor: COLORS.text,
          },
          columnStyles: {
            0: {
              fontStyle: "bold",
              cellWidth: 35,
              textColor: COLORS.primary,
              fillColor: COLORS.lightGray,
            },
            1: { cellWidth: "auto" },
          },
          margin: { left: 15, right: 15 },
        })

        yPosition = (doc as any).lastAutoTable.finalY + 10

        // Evidencia fotográfica (igual que normal)
        if (hallazgo.fotos.length > 0) {
          doc.setFontSize(10)
          doc.setFont("helvetica", "bold")
          doc.setTextColor(...COLORS.primary)
          doc.text("Evidencia Fotográfica:", 105, yPosition, { align: "center" })
          doc.setFont("helvetica", "normal")
          yPosition += 8

          const pageWidth = 210
          const margin = 20
          const photoWidth = pageWidth - 2 * margin // 170mm
          const maxPhotoHeight = 110
          const photoSpacing = 15

          for (let j = 0; j < hallazgo.fotos.length; j++) {
            const photoUrl = hallazgo.fotos[j]
            const optimizedImage = imageCache.get(photoUrl)

            if (!optimizedImage) {
              doc.setFontSize(9)
              doc.setTextColor(150, 150, 150)
              doc.text("Error al cargar imagen", 105, yPosition + 20, { align: "center" })
              yPosition += 40
              continue
            }

            try {
              const aspectRatio = optimizedImage.height / optimizedImage.width

              if (!aspectRatio || isNaN(aspectRatio) || aspectRatio <= 0) {
                console.error("[v0] Aspect ratio inválido:", aspectRatio)
                doc.setFontSize(9)
                doc.setTextColor(150, 150, 150)
                doc.text("Error: dimensiones inválidas", 105, yPosition + 20, { align: "center" })
                yPosition += 40
                continue
              }

              let finalWidth = photoWidth
              let finalHeight = photoWidth * aspectRatio

              // Si la foto es vertical y excede la altura máxima, ajustar por altura
              if (finalHeight > maxPhotoHeight) {
                finalHeight = maxPhotoHeight
                finalWidth = maxPhotoHeight / aspectRatio
              }

              if (yPosition + finalHeight > 270) {
                doc.addPage()
                yPosition = 20
              }

              const xPos = margin + (photoWidth - finalWidth) / 2

              doc.addImage(optimizedImage.dataUrl, "JPEG", xPos, yPosition, finalWidth, finalHeight)

              doc.setDrawColor(...COLORS.primary)
              doc.setLineWidth(0.5)
              doc.rect(xPos, yPosition, finalWidth, finalHeight)

              doc.setFontSize(8)
              doc.setTextColor(...COLORS.text)
              doc.text(`Foto ${j + 1} de ${hallazgo.fotos.length}`, 105, yPosition + finalHeight + 4, {
                align: "center",
              })

              yPosition += finalHeight + photoSpacing
            } catch (error) {
              console.error("[v0] Error agregando imagen al PDF:", error)
              doc.setFontSize(9)
              doc.setTextColor(150, 150, 150)
              doc.text("Error al procesar imagen", 105, yPosition + 20, { align: "center" })
              yPosition += 40
            }
          }
        } else {
          doc.setFontSize(9)
          doc.setTextColor(150, 150, 150)
          doc.text("Sin evidencia fotográfica", 105, yPosition, { align: "center" })
          yPosition += 5
        }

        if (hallazgo.fotos.length === 0) {
          yPosition += 10
        }
      }
    }

    // Footer en todas las páginas (igual que normal)
    const pageCount = doc.getNumberOfPages()
    for (let i = 1; i <= pageCount; i++) {
      doc.setPage(i)
      doc.setFontSize(8)
      doc.setTextColor(150, 150, 150)
      doc.text(`Página ${i} de ${pageCount} | Generado el ${new Date().toLocaleDateString("es-ES")}`, 105, 290, {
        align: "center",
      })
    }

    const fileName = `Informe_${data.lugar.replace(/[^a-zA-Z0-9]/g, "_")}_${new Date().toLocaleDateString("es-ES").replace(/\//g, "-")}.pdf`

    console.log("[v0] Guardando PDF...")
    doc.save(fileName)

    await new Promise((resolve) => setTimeout(resolve, 500))
    console.log("[v0] PDF generado y descargado exitosamente")
  } catch (error) {
    console.error("[v0] Error generando PDF de inspección rápida:", error)
    throw new Error("No se pudo generar el PDF. Por favor, intenta nuevamente.")
  }
}
