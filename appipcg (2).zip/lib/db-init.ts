"use server"

import { createClient } from "./supabase/server"

/**
 * Ejecuta un script SQL en la base de datos
 */
async function executeSQL(sql: string): Promise<{ success: boolean; error?: string }> {
  try {
    const supabase = await createClient()
    const { error } = await supabase.rpc("exec_sql", { sql_query: sql })

    if (error) {
      console.error("[v0] Error ejecutando SQL:", error)
      return { success: false, error: error.message }
    }

    return { success: true }
  } catch (error) {
    console.error("[v0] Error inesperado ejecutando SQL:", error)
    return { success: false, error: error instanceof Error ? error.message : String(error) }
  }
}

/**
 * Verifica si una tabla existe en la base de datos
 */
async function tableExists(tableName: string): Promise<boolean> {
  try {
    const supabase = await createClient()
    const { error } = await supabase.from(tableName).select("id").limit(1)

    // Si no hay error o el error no es "tabla no existe", la tabla existe
    return !error || (error.code !== "42P01" && error.code !== "PGRST116")
  } catch (error) {
    console.error(`[v0] Error verificando tabla ${tableName}:`, error)
    return false
  }
}

/**
 * Verifica si hay datos de ejemplo en la base de datos
 */
async function hasSampleData(): Promise<boolean> {
  try {
    const supabase = await createClient()
    const { data, error } = await supabase.from("areas").select("id").limit(1)

    if (error) return false
    return (data?.length ?? 0) > 0
  } catch (error) {
    return false
  }
}

/**
 * Crea las tablas básicas del sistema
 */
async function createTables(): Promise<{ success: boolean; error?: string }> {
  console.log("[v0] Creando tablas básicas...")

  const sql = `
-- Crear tablas para el sistema de inspecciones

-- Tabla de áreas
CREATE TABLE IF NOT EXISTS areas (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  responsible TEXT NOT NULL,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Tabla de checklists
CREATE TABLE IF NOT EXISTS checklists (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  area_id UUID REFERENCES areas(id) ON DELETE CASCADE,
  type TEXT CHECK (type IN ('normal', 'registro', 'manual', 'excel')) DEFAULT 'normal',
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Tabla de items de checklist
CREATE TABLE IF NOT EXISTS checklist_items (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  checklist_id UUID REFERENCES checklists(id) ON DELETE CASCADE,
  category TEXT NOT NULL,
  criterion TEXT NOT NULL,
  subcriterion TEXT,
  details TEXT,
  position INTEGER DEFAULT 0
);

-- Tabla de inspecciones
CREATE TABLE IF NOT EXISTS inspections (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  area_id UUID REFERENCES areas(id) ON DELETE CASCADE,
  checklist_id UUID REFERENCES checklists(id) ON DELETE CASCADE,
  inspector_name TEXT NOT NULL,
  date TIMESTAMPTZ DEFAULT NOW(),
  status TEXT CHECK (status IN ('en-progreso', 'completada', 'in_progress', 'completed')) DEFAULT 'en-progreso',
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Tabla de hallazgos (findings)
CREATE TABLE IF NOT EXISTS findings (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  inspection_id UUID REFERENCES inspections(id) ON DELETE CASCADE,
  item_id UUID NOT NULL,
  description TEXT,
  status TEXT CHECK (status IN ('conforme', 'no-conforme', 'pendiente', 'open', 'closed', 'in_progress')) NOT NULL,
  corrective_action TEXT,
  due_date TIMESTAMPTZ,
  closed_date TIMESTAMPTZ,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Tabla de fotos de hallazgos
CREATE TABLE IF NOT EXISTS finding_photos (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  finding_id UUID REFERENCES findings(id) ON DELETE CASCADE,
  photo_url TEXT NOT NULL,
  photo_type TEXT CHECK (photo_type IN ('evidence', 'solution')) DEFAULT 'evidence',
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Habilitar Row Level Security (RLS) en todas las tablas
ALTER TABLE areas ENABLE ROW LEVEL SECURITY;
ALTER TABLE checklists ENABLE ROW LEVEL SECURITY;
ALTER TABLE checklist_items ENABLE ROW LEVEL SECURITY;
ALTER TABLE inspections ENABLE ROW LEVEL SECURITY;
ALTER TABLE findings ENABLE ROW LEVEL SECURITY;
ALTER TABLE finding_photos ENABLE ROW LEVEL SECURITY;

-- Eliminar políticas existentes si existen
DROP POLICY IF EXISTS "Allow public access to areas" ON areas;
DROP POLICY IF EXISTS "Allow public access to checklists" ON checklists;
DROP POLICY IF EXISTS "Allow public access to checklist_items" ON checklist_items;
DROP POLICY IF EXISTS "Allow public access to inspections" ON inspections;
DROP POLICY IF EXISTS "Allow public access to findings" ON findings;
DROP POLICY IF EXISTS "Allow public access to finding_photos" ON finding_photos;

-- Políticas de acceso público (sin autenticación por ahora)
CREATE POLICY "Allow public access to areas" ON areas FOR ALL USING (true) WITH CHECK (true);
CREATE POLICY "Allow public access to checklists" ON checklists FOR ALL USING (true) WITH CHECK (true);
CREATE POLICY "Allow public access to checklist_items" ON checklist_items FOR ALL USING (true) WITH CHECK (true);
CREATE POLICY "Allow public access to inspections" ON inspections FOR ALL USING (true) WITH CHECK (true);
CREATE POLICY "Allow public access to findings" ON findings FOR ALL USING (true) WITH CHECK (true);
CREATE POLICY "Allow public access to finding_photos" ON finding_photos FOR ALL USING (true) WITH CHECK (true);
`

  try {
    const supabase = await createClient()

    // Ejecutar cada statement por separado para evitar errores
    const statements = sql
      .split(";")
      .map((s) => s.trim())
      .filter((s) => s.length > 0 && !s.startsWith("--"))

    for (const statement of statements) {
      const { error } = await supabase.rpc("exec_sql", { sql_query: statement })
      if (error && !error.message.includes("already exists")) {
        console.error("[v0] Error en statement:", error)
      }
    }

    console.log("[v0] Tablas creadas exitosamente")
    return { success: true }
  } catch (error) {
    console.error("[v0] Error creando tablas:", error)
    return { success: false, error: error instanceof Error ? error.message : String(error) }
  }
}

/**
 * Crea los índices para mejorar el rendimiento
 */
async function createIndexes(): Promise<{ success: boolean; error?: string }> {
  console.log("[v0] Creando índices...")

  const sql = `
-- Índices básicos
CREATE INDEX IF NOT EXISTS idx_checklists_area_id ON checklists(area_id);
CREATE INDEX IF NOT EXISTS idx_checklist_items_checklist_id ON checklist_items(checklist_id);
CREATE INDEX IF NOT EXISTS idx_inspections_area_id ON inspections(area_id);
CREATE INDEX IF NOT EXISTS idx_inspections_checklist_id ON inspections(checklist_id);
CREATE INDEX IF NOT EXISTS idx_inspections_date ON inspections(date DESC);
CREATE INDEX IF NOT EXISTS idx_findings_inspection_id ON findings(inspection_id);
CREATE INDEX IF NOT EXISTS idx_finding_photos_finding_id ON finding_photos(finding_id);
CREATE INDEX IF NOT EXISTS idx_finding_photos_finding_photo_type ON finding_photos(finding_id, photo_type);
`

  try {
    const supabase = await createClient()
    const statements = sql
      .split(";")
      .map((s) => s.trim())
      .filter((s) => s.length > 0 && !s.startsWith("--"))

    for (const statement of statements) {
      const { error } = await supabase.rpc("exec_sql", { sql_query: statement })
      if (error && !error.message.includes("already exists")) {
        console.error("[v0] Error creando índice:", error)
      }
    }

    console.log("[v0] Índices creados exitosamente")
    return { success: true }
  } catch (error) {
    console.error("[v0] Error creando índices:", error)
    return { success: false, error: error instanceof Error ? error.message : String(error) }
  }
}

/**
 * Inicializa la base de datos ejecutando todos los scripts necesarios
 * Esta función es idempotente y puede ejecutarse múltiples veces sin problemas
 */
export async function initializeDatabase() {
  try {
    console.log("[v0] Iniciando verificación de base de datos...")

    // Verificar si las tablas ya existen
    const areasExist = await tableExists("areas")

    if (areasExist) {
      console.log("[v0] Base de datos ya inicializada correctamente")
      return { success: true, message: "Base de datos ya inicializada" }
    }

    console.log("[v0] Inicializando base de datos por primera vez...")

    // Paso 1: Crear tablas
    const tablesResult = await createTables()
    if (!tablesResult.success) {
      return {
        success: false,
        message: "Error creando tablas",
        error: tablesResult.error,
      }
    }

    // Paso 2: Crear índices
    const indexesResult = await createIndexes()
    if (!indexesResult.success) {
      console.warn("[v0] Advertencia creando índices:", indexesResult.error)
    }

    console.log("[v0] Base de datos inicializada exitosamente")
    return {
      success: true,
      message: "Base de datos inicializada correctamente",
    }
  } catch (error) {
    console.error("[v0] Error en inicialización de base de datos:", error)
    return {
      success: false,
      message: "Error inesperado al inicializar base de datos",
      error: error instanceof Error ? error.message : String(error),
    }
  }
}

/**
 * Verifica si la base de datos está inicializada
 */
export async function isDatabaseInitialized(): Promise<boolean> {
  try {
    return await tableExists("areas")
  } catch (error) {
    console.error("[v0] Error verificando inicialización:", error)
    return false
  }
}
