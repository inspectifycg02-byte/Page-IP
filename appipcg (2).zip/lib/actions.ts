"use server"

import { revalidatePath } from "next/cache"
import type { Area, Checklist, Inspection } from "./types"
import {
  saveArea,
  deleteArea,
  getAreas,
  getChecklists,
  getChecklistsByArea,
  getChecklistById,
  saveChecklist,
  deleteChecklist,
  getInspections,
  getInspectionsByArea,
  getInspectionsByChecklist,
  getInspectionById,
  getInspectionsWithFindings,
  saveInspection,
  deleteInspection,
  exportData,
  clearAllData,
  importData,
  cleanOrphanedInspections,
} from "./storage.server"
import { uploadMultipleImagesToBlob } from "./blob-storage"
import { initializeDatabase, isDatabaseInitialized } from "./db-init"

export async function initializeDatabaseAction() {
  return await initializeDatabase()
}

export async function isDatabaseInitializedAction() {
  return await isDatabaseInitialized()
}

// Areas
export async function saveAreaAction(area: Area) {
  const result = await saveArea(area)
  revalidatePath("/")
  revalidatePath("/area")
  return result
}

export async function deleteAreaAction(id: string) {
  const result = await deleteArea(id)
  revalidatePath("/")
  revalidatePath("/area")
  return result
}

export async function getAreasAction() {
  return await getAreas()
}

// Checklists
export async function getChecklistsAction() {
  return await getChecklists()
}

export async function getChecklistsByAreaAction(areaId: string) {
  return await getChecklistsByArea(areaId)
}

export async function getChecklistByIdAction(id: string) {
  return await getChecklistById(id)
}

export async function saveChecklistAction(checklist: Checklist) {
  const result = await saveChecklist(checklist)
  revalidatePath("/")
  revalidatePath("/area")
  revalidatePath(`/area/${checklist.areaId}`)
  return result
}

export async function deleteChecklistAction(id: string) {
  const result = await deleteChecklist(id)
  revalidatePath("/")
  revalidatePath("/area")
  return result
}

// Inspections
export async function getInspectionsAction() {
  return await getInspections()
}

export async function getInspectionsByAreaAction(areaId: string) {
  return await getInspectionsByArea(areaId)
}

export async function getInspectionsByChecklistAction(checklistId: string) {
  return await getInspectionsByChecklist(checklistId)
}

export async function getInspectionByIdAction(id: string) {
  return await getInspectionById(id)
}

export async function getInspectionsWithFindingsAction() {
  return await getInspectionsWithFindings()
}

export async function saveInspectionAction(inspection: Inspection) {
  const result = await saveInspection(inspection)
  revalidatePath("/")
  revalidatePath("/historial")
  revalidatePath("/seguimiento")
  revalidatePath("/consolidado")
  revalidatePath("/comparativas")
  revalidatePath(`/area/${inspection.areaId}`)
  return result
}

export async function deleteInspectionAction(id: string) {
  const result = await deleteInspection(id)
  revalidatePath("/")
  revalidatePath("/historial")
  revalidatePath("/seguimiento")
  return result
}

// Data Management
export async function exportDataAction() {
  return await exportData()
}

export async function clearAllDataAction() {
  await clearAllData()
  revalidatePath("/")
}

export async function importDataAction(jsonData: string) {
  await importData(jsonData)
  revalidatePath("/")
}

export async function cleanOrphanedInspectionsAction() {
  await cleanOrphanedInspections()
  revalidatePath("/")
}

// Blob Storage Actions
export async function uploadPhotosAction(images: string[]): Promise<string[]> {
  // Subir hasta 15 imágenes en paralelo para máxima velocidad sin saturar el servidor
  return await uploadMultipleImagesToBlob(images, undefined, 15)
}
