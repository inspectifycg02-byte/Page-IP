"use server"

import type { Area, Checklist, Inspection } from "./types"
import { createClient } from "./supabase/server"

// Areas
export async function getAreas(): Promise<Area[]> {
  const supabase = await createClient()
  const { data, error } = await supabase.from("areas").select("*").order("created_at", { ascending: false })

  if (error) {
    console.error("[v0] Error fetching areas:", error)
    return []
  }

  return (
    data?.map((area) => ({
      id: area.id,
      name: area.name,
      responsible: area.responsible || "",
      createdAt: area.created_at,
    })) || []
  )
}

export async function saveArea(area: Area): Promise<{ success: boolean; id?: string; error?: string }> {
  const supabase = await createClient()

  const isUUID = area.id.match(/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i)

  if (isUUID) {
    const { error } = await supabase
      .from("areas")
      .update({
        name: area.name,
        responsible: area.responsible,
      })
      .eq("id", area.id)

    if (error) {
      console.error("[v0] Error updating area:", error)
      return { success: false, error: error.message }
    }
    return { success: true, id: area.id }
  } else {
    const { data, error } = await supabase
      .from("areas")
      .insert({
        name: area.name,
        responsible: area.responsible,
      })
      .select()
      .single()

    if (error) {
      console.error("[v0] Error inserting area:", error)
      return { success: false, error: error.message }
    }
    return { success: true, id: data.id }
  }
}

export async function deleteArea(id: string): Promise<{ success: boolean; error?: string }> {
  const supabase = await createClient()

  try {
    const { data: inspections } = await supabase.from("inspections").select("id").eq("area_id", id)
    const inspectionIds = inspections?.map((i) => i.id) || []

    if (inspectionIds.length > 0) {
      const { data: findings } = await supabase.from("findings").select("id").in("inspection_id", inspectionIds)
      const findingIds = findings?.map((f) => f.id) || []

      if (findingIds.length > 0) {
        await supabase.from("finding_photos").delete().in("finding_id", findingIds)
      }

      await supabase.from("findings").delete().in("inspection_id", inspectionIds)
      await supabase.from("inspections").delete().eq("area_id", id)
    }

    const { data: checklists } = await supabase.from("checklists").select("id").eq("area_id", id)
    const checklistIds = checklists?.map((c) => c.id) || []

    if (checklistIds.length > 0) {
      await supabase.from("checklist_items").delete().in("checklist_id", checklistIds)
      await supabase.from("checklists").delete().eq("area_id", id)
    }

    const { error } = await supabase.from("areas").delete().eq("id", id)

    if (error) {
      console.error("[v0] Error deleting area:", error)
      return { success: false, error: error.message }
    }

    return { success: true }
  } catch (error: any) {
    console.error("[v0] Error deleting area:", error)
    return { success: false, error: error.message }
  }
}

// Checklists
export async function getChecklists(): Promise<Checklist[]> {
  const supabase = await createClient()
  const { data: checklistsData, error: checklistsError } = await supabase
    .from("checklists")
    .select("*")
    .order("created_at", { ascending: false })

  if (checklistsError) {
    console.error("[v0] Error fetching checklists:", checklistsError)
    return []
  }

  const checklists: Checklist[] = []
  for (const checklist of checklistsData || []) {
    const { data: itemsData, error: itemsError } = await supabase
      .from("checklist_items")
      .select("*")
      .eq("checklist_id", checklist.id)
      .order("position", { ascending: true })

    if (itemsError) {
      console.error("[v0] Error fetching checklist items:", itemsError)
      continue
    }

    checklists.push({
      id: checklist.id,
      name: checklist.name,
      areaId: checklist.area_id,
      type: checklist.type as "normal" | "registro",
      createdAt: checklist.created_at,
      items:
        itemsData?.map((item) => ({
          id: item.id,
          category: item.category,
          criterion: item.criterion,
          subcriterion: item.subcriterion,
          details: item.details,
        })) || [],
    })
  }

  return checklists
}

export async function getChecklistsByArea(areaId: string): Promise<Checklist[]> {
  const supabase = await createClient()
  const { data: checklistsData, error: checklistsError } = await supabase
    .from("checklists")
    .select("*")
    .eq("area_id", areaId)
    .order("created_at", { ascending: false })

  if (checklistsError) {
    console.error("[v0] Error fetching checklists by area:", checklistsError)
    return []
  }

  const checklists: Checklist[] = []
  for (const checklist of checklistsData || []) {
    const { data: itemsData, error: itemsError } = await supabase
      .from("checklist_items")
      .select("*")
      .eq("checklist_id", checklist.id)
      .order("position", { ascending: true })

    if (itemsError) {
      console.error("[v0] Error fetching checklist items:", itemsError)
      continue
    }

    checklists.push({
      id: checklist.id,
      name: checklist.name,
      areaId: checklist.area_id,
      type: checklist.type as "normal" | "registro",
      createdAt: checklist.created_at,
      items:
        itemsData?.map((item) => ({
          id: item.id,
          category: item.category,
          criterion: item.criterion,
          subcriterion: item.subcriterion,
          details: item.details,
        })) || [],
    })
  }

  return checklists
}

export async function getChecklistById(id: string): Promise<Checklist | null> {
  const supabase = await createClient()
  const { data: checklistData, error: checklistError } = await supabase
    .from("checklists")
    .select("*")
    .eq("id", id)
    .single()

  if (checklistError) {
    console.error("[v0] Error fetching checklist:", checklistError)
    return null
  }

  const { data: itemsData, error: itemsError } = await supabase
    .from("checklist_items")
    .select("*")
    .eq("checklist_id", checklistData.id)
    .order("position", { ascending: true })

  if (itemsError) {
    console.error("[v0] Error fetching checklist items:", itemsError)
    return null
  }

  return {
    id: checklistData.id,
    name: checklistData.name,
    areaId: checklistData.area_id,
    type: checklistData.type as "normal" | "registro",
    createdAt: checklistData.created_at,
    items:
      itemsData?.map((item) => ({
        id: item.id,
        category: item.category,
        criterion: item.criterion,
        subcriterion: item.subcriterion,
        details: item.details,
      })) || [],
  }
}

export async function saveChecklist(checklist: Checklist): Promise<{ success: boolean; id?: string; error?: string }> {
  const supabase = await createClient()

  const isUUID = checklist.id.match(/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i)

  let checklistExists = false
  if (isUUID) {
    const { data: existingChecklist } = await supabase.from("checklists").select("id").eq("id", checklist.id).single()

    checklistExists = !!existingChecklist
  }

  if (isUUID && checklistExists) {
    const { error: checklistError } = await supabase
      .from("checklists")
      .update({
        name: checklist.name,
        area_id: checklist.areaId,
        type: checklist.type || "normal",
      })
      .eq("id", checklist.id)

    if (checklistError) {
      console.error("[v0] Error updating checklist:", checklistError)
      return { success: false, error: checklistError.message }
    }

    await supabase.from("checklist_items").delete().eq("checklist_id", checklist.id)

    if (checklist.items && checklist.items.length > 0) {
      const { error: itemsError } = await supabase.from("checklist_items").insert(
        checklist.items.map((item, index) => ({
          checklist_id: checklist.id,
          category: item.category,
          criterion: item.criterion,
          subcriterion: item.subcriterion,
          details: item.details,
          position: index,
        })),
      )

      if (itemsError) {
        console.error("[v0] Error updating checklist items:", itemsError)
        return { success: false, error: itemsError.message }
      }
    }

    return { success: true, id: checklist.id }
  } else {
    // If it's a valid UUID that doesn't exist, preserve it; otherwise let DB generate new one
    const insertData: any = {
      name: checklist.name,
      area_id: checklist.areaId,
      type: checklist.type || "normal",
    }

    // Only include ID if it's a valid UUID (to preserve IDs during import)
    if (isUUID) {
      insertData.id = checklist.id
    }

    const { data: checklistData, error: checklistError } = await supabase
      .from("checklists")
      .insert(insertData)
      .select()
      .single()

    if (checklistError) {
      console.error("[v0] Error inserting checklist:", checklistError)
      return { success: false, error: checklistError.message }
    }

    if (checklist.items && checklist.items.length > 0) {
      const { error: itemsError } = await supabase.from("checklist_items").insert(
        checklist.items.map((item, index) => ({
          checklist_id: checklistData.id,
          category: item.category,
          criterion: item.criterion,
          subcriterion: item.subcriterion,
          details: item.details,
          position: index,
        })),
      )

      if (itemsError) {
        console.error("[v0] Error inserting checklist items:", itemsError)
        return { success: false, error: itemsError.message }
      }
    }

    return { success: true, id: checklistData.id }
  }
}

export async function deleteChecklist(id: string): Promise<{ success: boolean; error?: string }> {
  const supabase = await createClient()
  const { error } = await supabase.from("checklists").delete().eq("id", id)

  if (error) {
    console.error("[v0] Error deleting checklist:", error)
    return { success: false, error: error.message }
  }
  return { success: true }
}

// Inspections
export async function getInspections(): Promise<Inspection[]> {
  const supabase = await createClient()

  // Fetch inspections without nested data for better performance
  const { data: inspectionsData, error: inspectionsError } = await supabase
    .from("inspections")
    .select("*")
    .order("date", { ascending: false })
    .limit(500) // Limit to most recent 500 inspections

  if (inspectionsError) {
    console.error("[v0] Error fetching inspections:", inspectionsError)
    return []
  }

  // Fetch findings count for each inspection in a single query
  const inspectionIds = inspectionsData?.map((i) => i.id) || []
  const { data: findingsData } = await supabase
    .from("findings")
    .select("inspection_id, id")
    .in("inspection_id", inspectionIds)

  // Group findings by inspection_id
  const findingsByInspection = (findingsData || []).reduce((acc: Record<string, number>, finding: any) => {
    acc[finding.inspection_id] = (acc[finding.inspection_id] || 0) + 1
    return acc
  }, {})

  return (inspectionsData || []).map((inspection: any) => ({
    id: inspection.id,
    areaId: inspection.area_id,
    checklistId: inspection.checklist_id,
    date: inspection.date,
    inspectorName: inspection.inspector_name,
    status: inspection.status as "en-progreso" | "completada",
    findings: Array(findingsByInspection[inspection.id] || 0).fill({
      id: "",
      itemId: "",
      description: "",
      status: "pendiente" as const,
      correctiveAction: "",
      dueDate: "",
      closedDate: "",
      photos: [],
      solutionPhotos: [],
    }),
  }))
}

export async function getInspectionsByArea(areaId: string): Promise<Inspection[]> {
  const supabase = await createClient()
  const { data: inspectionsData, error: inspectionsError } = await supabase
    .from("inspections")
    .select("*")
    .eq("area_id", areaId)
    .order("date", { ascending: false })

  if (inspectionsError) {
    console.error("[v0] Error fetching inspections by area:", inspectionsError)
    return []
  }

  return (inspectionsData || []).map((inspection: any) => ({
    id: inspection.id,
    areaId: inspection.area_id,
    checklistId: inspection.checklist_id,
    date: inspection.date,
    inspectorName: inspection.inspector_name,
    status: inspection.status as "en-progreso" | "completada",
    findings: [],
  }))
}

export async function getInspectionsByChecklist(checklistId: string): Promise<Inspection[]> {
  const supabase = await createClient()
  const { data: inspectionsData, error: inspectionsError } = await supabase
    .from("inspections")
    .select("*")
    .eq("checklist_id", checklistId)
    .order("date", { ascending: false })

  if (inspectionsError) {
    console.error("[v0] Error fetching inspections by checklist:", inspectionsError)
    return []
  }

  return (inspectionsData || []).map((inspection: any) => ({
    id: inspection.id,
    areaId: inspection.area_id,
    checklistId: inspection.checklist_id,
    date: inspection.date,
    inspectorName: inspection.inspector_name,
    status: inspection.status as "en-progreso" | "completada",
    findings: [],
  }))
}

export async function getInspectionById(id: string): Promise<Inspection | null> {
  const isUUID = id.match(/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i)

  if (!isUUID) {
    console.log("[v0] Non-UUID inspection ID provided, cannot fetch from database:", id)
    return null
  }

  const supabase = await createClient()

  const { data: inspectionData, error: inspectionError } = await supabase
    .from("inspections")
    .select(`
      *,
      findings (
        *,
        finding_photos (*)
      )
    `)
    .eq("id", id)
    .single()

  if (inspectionError) {
    console.error("[v0] Error fetching inspection:", inspectionError)
    return null
  }

  if (!inspectionData) return null

  return {
    id: inspectionData.id,
    areaId: inspectionData.area_id,
    checklistId: inspectionData.checklist_id,
    date: inspectionData.date,
    inspectorName: inspectionData.inspector_name,
    status: inspectionData.status as "en-progreso" | "completada",
    findings: (inspectionData.findings || []).map((finding: any) => ({
      id: finding.id,
      itemId: finding.item_id,
      description: finding.description || "",
      status: finding.status as "conforme" | "no-conforme" | "pendiente",
      correctiveAction: finding.corrective_action || "",
      dueDate: finding.due_date || "",
      closedDate: finding.closed_date || "",
      photos: (finding.finding_photos || [])
        .filter((p: any) => p.photo_type === "evidence")
        .map((p: any) => p.photo_url),
      solutionPhotos: (finding.finding_photos || [])
        .filter((p: any) => p.photo_type === "solution")
        .map((p: any) => p.photo_url),
    })),
  }
}

export async function saveInspection(
  inspection: Inspection,
): Promise<{ success: boolean; id?: string; error?: string }> {
  const supabase = await createClient()

  const isUUID = inspection.id.match(/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i)

  if (isUUID) {
    const { error: inspectionError } = await supabase
      .from("inspections")
      .update({
        area_id: inspection.areaId,
        checklist_id: inspection.checklistId,
        inspector_name: inspection.inspectorName,
        date: inspection.date,
        status: inspection.status,
      })
      .eq("id", inspection.id)

    if (inspectionError) {
      console.error("[v0] Error updating inspection:", inspectionError)
      return { success: false, error: inspectionError.message }
    }

    await supabase.from("findings").delete().eq("inspection_id", inspection.id)

    if (inspection.findings && inspection.findings.length > 0) {
      for (const finding of inspection.findings) {
        const { data: findingData, error: findingError } = await supabase
          .from("findings")
          .insert({
            inspection_id: inspection.id,
            item_id: finding.itemId,
            description: finding.description,
            status: finding.status,
            corrective_action: finding.correctiveAction,
            due_date: finding.dueDate || null,
            closed_date: finding.closedDate || null,
          })
          .select()
          .single()

        if (findingError) {
          console.error("[v0] Error inserting finding:", findingError)
          continue
        }

        if (finding.photos && finding.photos.length > 0) {
          await supabase.from("finding_photos").insert(
            finding.photos.map((photo) => ({
              finding_id: findingData.id,
              photo_url: photo,
              photo_type: "evidence",
            })),
          )
        }

        if (finding.solutionPhotos && finding.solutionPhotos.length > 0) {
          await supabase.from("finding_photos").insert(
            finding.solutionPhotos.map((photo) => ({
              finding_id: findingData.id,
              photo_url: photo,
              photo_type: "solution",
            })),
          )
        }
      }
    }

    return { success: true, id: inspection.id }
  } else {
    const { data: inspectionData, error: inspectionError } = await supabase
      .from("inspections")
      .insert({
        area_id: inspection.areaId,
        checklist_id: inspection.checklistId,
        inspector_name: inspection.inspectorName,
        date: inspection.date,
        status: inspection.status,
      })
      .select()
      .single()

    if (inspectionError) {
      console.error("[v0] Error inserting inspection:", inspectionError)
      return { success: false, error: inspectionError.message }
    }

    if (inspection.findings && inspection.findings.length > 0) {
      for (const finding of inspection.findings) {
        const { data: findingData, error: findingError } = await supabase
          .from("findings")
          .insert({
            inspection_id: inspectionData.id,
            item_id: finding.itemId,
            description: finding.description,
            status: finding.status,
            corrective_action: finding.correctiveAction,
            due_date: finding.dueDate || null,
            closed_date: finding.closedDate || null,
          })
          .select()
          .single()

        if (findingError) {
          console.error("[v0] Error inserting finding:", findingError)
          continue
        }

        if (finding.photos && finding.photos.length > 0) {
          await supabase.from("finding_photos").insert(
            finding.photos.map((photo) => ({
              finding_id: findingData.id,
              photo_url: photo,
              photo_type: "evidence",
            })),
          )
        }

        if (finding.solutionPhotos && finding.solutionPhotos.length > 0) {
          await supabase.from("finding_photos").insert(
            finding.solutionPhotos.map((photo) => ({
              finding_id: findingData.id,
              photo_url: photo,
              photo_type: "solution",
            })),
          )
        }
      }
    }

    return { success: true, id: inspectionData.id }
  }
}

export async function deleteInspection(id: string): Promise<{ success: boolean; error?: string }> {
  const supabase = await createClient()
  const { error } = await supabase.from("inspections").delete().eq("id", id)

  if (error) {
    console.error("[v0] Error deleting inspection:", error)
    return { success: false, error: error.message }
  }
  return { success: true }
}

// Data Management Functions
export async function exportData(): Promise<string> {
  const areas = await getAreas()
  const checklists = await getChecklists()
  const inspections = await getInspections()

  return JSON.stringify({
    areas,
    checklists,
    inspections,
    exportDate: new Date().toISOString(),
  })
}

export async function clearAllData(): Promise<void> {
  const supabase = await createClient()

  // Delete in order to respect foreign key constraints
  // First delete photos (depends on findings)
  await supabase.from("finding_photos").delete().not("id", "is", null)

  // Then delete findings (depends on inspections)
  await supabase.from("findings").delete().not("id", "is", null)

  // Then delete inspections (depends on areas and checklists)
  await supabase.from("inspections").delete().not("id", "is", null)

  // Delete checklist items (depends on checklists)
  await supabase.from("checklist_items").delete().not("id", "is", null)

  // Delete criteria (depends on subcategories)
  await supabase.from("criteria").delete().not("id", "is", null)

  // Delete subcategories (depends on categories)
  await supabase.from("subcategories").delete().not("id", "is", null)

  // Delete categories (depends on checklists)
  await supabase.from("categories").delete().not("id", "is", null)

  // Delete checklists (depends on areas)
  await supabase.from("checklists").delete().not("id", "is", null)

  // Finally delete areas (no dependencies)
  await supabase.from("areas").delete().not("id", "is", null)

  // Delete inspectors and photo_types (independent tables)
  await supabase.from("inspectors").delete().not("id", "is", null)
  await supabase.from("photo_types").delete().not("id", "is", null)
}

export async function cleanOrphanedInspections(): Promise<void> {
  const supabase = await createClient()

  // Delete inspections where area_id doesn't exist in areas table
  await supabase.from("inspections").delete().not("area_id", "in", supabase.from("areas").select("id"))

  // Delete inspections where checklist_id doesn't exist in checklists table
  await supabase.from("inspections").delete().not("checklist_id", "in", supabase.from("checklists").select("id"))
}

export async function importData(jsonData: string): Promise<void> {
  try {
    const data = JSON.parse(jsonData)

    const areaIdMap = new Map<string, string>()
    const checklistIdMap = new Map<string, string>()

    // Import areas and create ID mapping
    if (data.areas) {
      for (const area of data.areas) {
        const oldId = area.id
        const result = await saveArea(area)
        if (result.success && result.id) {
          areaIdMap.set(oldId, result.id)
          console.log(`[v0] Area imported: ${area.name} (${oldId} -> ${result.id})`)
        }
      }
    }

    // Import checklists and create ID mapping
    if (data.checklists) {
      for (const checklist of data.checklists) {
        const oldId = checklist.id
        const oldAreaId = checklist.areaId

        // Update areaId if it was remapped
        if (areaIdMap.has(oldAreaId)) {
          checklist.areaId = areaIdMap.get(oldAreaId)
        }

        const result = await saveChecklist(checklist)
        if (result.success && result.id) {
          checklistIdMap.set(oldId, result.id)
          console.log(`[v0] Checklist imported: ${checklist.name} (${oldId} -> ${result.id})`)
        }
      }
    }

    // Import inspections with updated IDs
    if (data.inspections) {
      for (const inspection of data.inspections) {
        const oldAreaId = inspection.areaId
        const oldChecklistId = inspection.checklistId

        // Update areaId if it was remapped
        if (areaIdMap.has(oldAreaId)) {
          inspection.areaId = areaIdMap.get(oldAreaId)
        }

        // Update checklistId if it was remapped
        if (checklistIdMap.has(oldChecklistId)) {
          inspection.checklistId = checklistIdMap.get(oldChecklistId)
        }

        if (inspection.findings) {
          inspection.findings = inspection.findings.filter((finding: any) => {
            // Remove findings with empty or invalid IDs
            if (!finding.itemId || finding.itemId === "") {
              console.log(`[v0] Skipping finding with empty itemId`)
              return false
            }
            return true
          })
        }

        const result = await saveInspection(inspection)
        if (result.success) {
          console.log(`[v0] Inspection imported: ${inspection.inspectorName} - ${inspection.date}`)
        }
      }
    }

    console.log(`[v0] Import completed successfully`)
    console.log(`[v0] - ${areaIdMap.size} areas imported`)
    console.log(`[v0] - ${checklistIdMap.size} checklists imported`)
  } catch (error) {
    console.error("[v0] Error importing data:", error)
    throw error
  }
}

export async function getInspectionsWithFindings(): Promise<Inspection[]> {
  const supabase = await createClient()

  // Fetch inspections
  const { data: inspectionsData, error: inspectionsError } = await supabase
    .from("inspections")
    .select("*")
    .order("date", { ascending: false })
    .limit(500)

  if (inspectionsError) {
    console.error("[v0] Error fetching inspections:", inspectionsError)
    return []
  }

  const inspectionIds = inspectionsData?.map((i) => i.id) || []

  if (inspectionIds.length === 0) {
    return []
  }

  // Fetch all findings for these inspections
  const { data: findingsData, error: findingsError } = await supabase
    .from("findings")
    .select("*")
    .in("inspection_id", inspectionIds)

  if (findingsError) {
    console.error("[v0] Error fetching findings:", findingsError)
  }

  const findingIds = findingsData?.map((f) => f.id) || []

  // Fetch all photos for these findings
  let photosData: any[] = []
  if (findingIds.length > 0) {
    const { data, error: photosError } = await supabase.from("finding_photos").select("*").in("finding_id", findingIds)

    if (photosError) {
      console.error("[v0] Error fetching photos:", photosError)
    } else {
      photosData = data || []
    }
  }

  // Group photos by finding_id
  const photosByFinding = photosData.reduce((acc: Record<string, any[]>, photo: any) => {
    if (!acc[photo.finding_id]) {
      acc[photo.finding_id] = []
    }
    acc[photo.finding_id].push(photo)
    return acc
  }, {})

  // Group findings by inspection_id
  const findingsByInspection = (findingsData || []).reduce((acc: Record<string, any[]>, finding: any) => {
    if (!acc[finding.inspection_id]) {
      acc[finding.inspection_id] = []
    }

    const findingPhotos = photosByFinding[finding.id] || []

    acc[finding.inspection_id].push({
      id: finding.id,
      itemId: finding.item_id,
      description: finding.description || "",
      status: finding.status as "conforme" | "no-conforme" | "pendiente",
      correctiveAction: finding.corrective_action || "",
      dueDate: finding.due_date || "",
      closedDate: finding.closed_date || "",
      photos: findingPhotos.filter((p) => p.photo_type === "evidence").map((p) => p.photo_url),
      solutionPhotos: findingPhotos.filter((p) => p.photo_type === "solution").map((p) => p.photo_url),
    })
    return acc
  }, {})

  return (inspectionsData || []).map((inspection: any) => ({
    id: inspection.id,
    areaId: inspection.area_id,
    checklistId: inspection.checklist_id,
    date: inspection.date,
    inspectorName: inspection.inspector_name,
    status: inspection.status as "en-progreso" | "completada",
    findings: findingsByInspection[inspection.id] || [],
  }))
}
