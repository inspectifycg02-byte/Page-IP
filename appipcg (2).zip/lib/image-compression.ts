/**
 * Compresses an image file to reduce size for mobile performance
 * @param file - The image file to compress
 * @param maxWidth - Maximum width in pixels (default: 1200, reduced for mobile)
 * @param maxHeight - Maximum height in pixels (default: 1200, reduced for mobile)
 * @param quality - JPEG quality 0-1 (default: 0.7, reduced for smaller file size)
 * @param maxSizeInMB - Maximum file size in MB (default: 3MB)
 * @returns Promise with compressed base64 string
 */
export async function compressImage(
  file: File,
  maxWidth = 1200,
  maxHeight = 1200,
  quality = 0.7,
  maxSizeInMB = 3,
): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader()

    reader.onerror = () => reject(new Error("Error reading file"))

    reader.onload = (e) => {
      const img = new Image()

      img.onerror = () => reject(new Error("Error loading image"))

      img.onload = () => {
        // Calculate new dimensions while maintaining aspect ratio
        let width = img.width
        let height = img.height

        if (width > maxWidth) {
          height = (height * maxWidth) / width
          width = maxWidth
        }

        if (height > maxHeight) {
          width = (width * maxHeight) / height
          height = maxHeight
        }

        // Create canvas and draw resized image
        const canvas = document.createElement("canvas")
        canvas.width = width
        canvas.height = height

        const ctx = canvas.getContext("2d")
        if (!ctx) {
          reject(new Error("Could not get canvas context"))
          return
        }

        // Draw image on canvas
        ctx.drawImage(img, 0, 0, width, height)

        const currentQuality = quality
        let compressedBase64 = canvas.toDataURL("image/jpeg", currentQuality)

        // Calculate size in MB
        const sizeInMB = (compressedBase64.length * 0.75) / (1024 * 1024)

        // If image is still too large, reduce quality further
        if (sizeInMB > maxSizeInMB && currentQuality > 0.3) {
          // Calculate target quality to reach desired size
          const targetQuality = Math.max(0.3, (maxSizeInMB / sizeInMB) * currentQuality)
          compressedBase64 = canvas.toDataURL("image/jpeg", targetQuality)
        }

        resolve(compressedBase64)
      }

      img.src = e.target?.result as string
    }

    reader.readAsDataURL(file)
  })
}

/**
 * Compresses multiple images in batches with non-blocking processing
 * Optimized to handle up to 200 photos without freezing the UI
 * @param files - Array of image files
 * @param onProgress - Callback for progress updates
 * @param batchSize - Number of images to process in each batch (default: 10)
 * @returns Promise with array of compressed base64 strings
 */
export async function compressMultipleImages(
  files: File[],
  onProgress?: (current: number, total: number) => void,
  batchSize = 10,
): Promise<string[]> {
  const compressed: string[] = []
  const total = files.length

  // Process in batches to avoid blocking the UI
  for (let i = 0; i < total; i += batchSize) {
    const batch = files.slice(i, Math.min(i + batchSize, total))

    // Process batch in parallel
    const batchPromises = batch.map((file) => compressImage(file))
    const batchResults = await Promise.allSettled(batchPromises)

    // Collect successful compressions
    for (const result of batchResults) {
      if (result.status === "fulfilled") {
        compressed.push(result.value)
      } else {
        console.error("Error compressing image:", result.reason)
      }
    }

    // Update progress
    if (onProgress) {
      onProgress(Math.min(i + batchSize, total), total)
    }

    // Yield to the browser to keep UI responsive
    // Only add delay if there are more batches to process
    if (i + batchSize < total) {
      await new Promise((resolve) => setTimeout(resolve, 10))
    }
  }

  return compressed
}
